/**
 * @brief It implements the character interface
 *
 * @file character.c
 * @author Javier Jarque and Salvador Alcala
 * @version 1,2
 * @date 25-02-2026
 * @copyright GNU Public License
 */

#include "character.h"

#include "player.h"

#include "types.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

struct Character_
{
    Id id;         /*!< Id number of the character, it must be unique */
    char *name;    /*!< Name of the character */
    char *gdesc;   /*!< Graphical description of the character, it must be a string of WORD_SIZE characters maximum */
    int health;    /*!< Health of the character, it must be a positive integer */
    Bool friendly; /*!< If the character is friendly or not, it must be a boolean */
    char *message; /*!< Message of the character, it must be a string of WORD_SIZE characters maximum */
};

Character *character_create(Id id)
{
    Character *newCharacter = NULL;

    /* Error control */
    if (id == NO_ID)
    {
        return NULL;
    }
    newCharacter = (Character *)calloc(1, sizeof(Character));
    if (newCharacter == NULL)
    {
        return NULL;
    }
    newCharacter->id = id;
    newCharacter->health = MAX_PLAYER_HEALTH;
    newCharacter->message = NULL;
    newCharacter->friendly = FALSE;

    return newCharacter;
}

void character_destroy(Character *character)
{
    if (character != NULL)
    {
        free(character->name);
        free(character->gdesc);

        if (character->message)
        {
            free(character->message);
        }
        free(character);
    }
}

Id character_get_id(Character *character)
{
    if (character == NULL)
    {
        return NO_ID;
    }
    return character->id;
}

Status character_set_id(Character *character, Id id)
{
    if (!character || id == NO_ID)
    {
        return ERROR;
    }
    character->id = id;
    return OK;
}

Status character_set_name(Character *character, char *name)
{
    if (!character || !name)
    {
        return ERROR;
    }

    if (character->name)
    {
        free(character->name);
    }

    character->name = (char *)malloc(strlen(name) + 1);
    if (!character->name)
    {
        return ERROR;
    }
    strcpy(character->name, name);

    return OK;
}

char *character_get_name(Character *character)
{
    if (!character)
    {
        return NULL;
    }
    return character->name;
}

Status character_set_gdesc(Character *character, char *gdesc)
{
    if (!character || !gdesc)
    {
        return ERROR;
    }

    if (character->gdesc)
    {
        free(character->gdesc);
    }

    character->gdesc = gdesc;
    return OK;
}

char *character_get_gdesc(Character *character)
{
    if (!character)
    {
        return NULL;
    }
    return character->gdesc;
}

Status character_set_health(Character *character, int health)
{
    if (!character)
    {
        return ERROR;
    }
    character->health = health;
    return OK;
}

int character_get_health(Character *character)
{
    if (!character)
    {
        return -1;
    }
    return character->health;
}

Status character_set_friendly(Character *character, Bool friendly)
{
    if (!character)
    {
        return ERROR;
    }
    character->friendly = friendly;
    return OK;
}

Bool character_get_friendly(Character *character)
{
    if (!character)
    {
        return FALSE;
    }
    return character->friendly;
}

Status character_set_message(Character *character, char *message)
{
    if (!character || !message)
    {
        return ERROR;
    }

    if (character->message)
    {
        free(character->message);
    }

    character->message = message;
    return OK;
}

char *character_get_message(Character *character)
{
    if (!character)
    {
        return NULL;
    }
    return character->message;
}

Status character_print(Character *character)
{

    /* Error Control */
    if (!character)
    {
        return ERROR;
    }

    /* 1. Print the id and the name of the character */
    fprintf(stdout, "--> Character (Id: %ld; Name: %s)\n", character->id, character->name);

    /* 2. Print the gdesc of the player*/
    fprintf(stdout, "--> Gdesc (gdesc: %s)\n", character->gdesc);

    /* 3. Print the health of the character*/
    fprintf(stdout, "--> Gdesc (gdesc: %i)\n", character->health);

    /* 4. Print if the character is friendly or not */
    if (character_get_friendly(character))
    {
        fprintf(stdout, "---> The character is friendly.\n");
    }
    else
    {
        fprintf(stdout, "---> The character isn't friendly.\n");
    }

    /* 5. Print the message of the character*/
    fprintf(stdout, "--> Message (message: %s)\n", character->message);

    return OK;
}