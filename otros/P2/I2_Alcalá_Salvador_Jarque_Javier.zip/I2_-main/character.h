/**
 * @brief It defines the character interface
 *
 * @file character.h
 * @author Javier Jarque and Salvador Alcala
 * @version 1.3
 * @date 15-03-2026
 * @copyright GNU Public License
 */
#ifndef CHARACTER_H
#define CHARACTER_H

#include "types.h"
#include "object.h"

/**
 * @brief Character
 *
 * This struct stores all the information of a character
 */
typedef struct Character_ Character;

/**
 * @brief It creates a new character, allocating memory and initializing its members
 * @author Javier Jarque
 *
 * @param id the identification number for the new character
 * @return a new character, initialized
 */
Character *character_create(Id id);

/**
 * @brief It destroys a character, freeing the allocated memory
 * @author Javier Jarque
 *
 * @param character a pointer to the character that must be destroyed
 */
void character_destroy(Character *character);

/**
 * @brief It gets the id of a character
 * @author Javier Jarque
 *
 * @param character a pointer to the character
 * @return the id of character
 */
Id character_get_id(Character *character);

/**
 * @brief If sets the id of a character
 * @author Javier Jarque
 *
 * @param character a pointer to the character
 * @param id the id to set
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status character_set_id(Character *character, Id id);

/**
 * @brief It sets the name of a character
 * @author Javier Jarque
 *
 * @param character a pointer to the character
 * @param name a string with the name to store
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status character_set_name(Character *character, char *name);

/**
 * @brief It gets the name of a character
 * @author Javier Jarque
 *
 * @param character a pointer to the character
 * @return a string with the name of the character
 */
char *character_get_name(Character *character);

/**
 * @brief If sets the gdesc of a character
 * @author Javier Jarque
 *
 * @param character a pointer to the character
 * @param gdesc the gdesc to set
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status character_set_gdesc(Character *character, char *gdesc);

/**
 * @brief It gets the name of a character
 * @author Javier Jarque and Salvador Alcalá
 *
 * @param character a pointer to the character
 * @return a string with the gdesc of the character
 */
char *character_get_gdesc(Character *character);

/**
 * @brief If sets the health of a character
 * @author Javier Jarque
 *
 * @param character a pointer to the character
 * @param health the health to set
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status character_set_health(Character *character, int health);

/**
 * @brief It gets the name of a character
 * @author Javier Jarque and Salvador Alcala
 *
 * @param character a pointer to the character
 * @return a int with the health of the character, or -1 if there was some mistake
 */
int character_get_health(Character *character);

/**
 * @brief If sets if the character is friendly or not
 * @author Javier Jarque
 *
 * @param character a pointer to the character
 * @param friendly if the character is friendly or not
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status character_set_friendly(Character *character, Bool friendly);

/**
 * @brief It gets the name of a character
 * @author Javier Jarque and Salvador Alcala
 *
 * @param character a pointer to the character
 * @return a Bool parameter with the friendly of the character or FALSE if it was some mistake
 */
Bool character_get_friendly(Character *character);

/**
 * @brief If sets the message of a character
 * @author Javier Jarque
 *
 * @param character a pointer to the character
 * @param gdesc the message to set
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status character_set_message(Character *character, char *message);

/**
 * @brief It gets the message of a character
 * @author Javier Jarque and Salvador Alcalá
 *
 * @param character a pointer to the character
 * @return a string with the message of the character
 */
char *character_get_message(Character *character);

/**
 * @brief It prints the character information
 * @author Javier Jarque
 *
 * This fucntion shows the id and name of the character, the gdesc, the health, if the character is friendly and the message of the character
 * @param character a pointer to the character
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status character_print(Character *character);

#endif