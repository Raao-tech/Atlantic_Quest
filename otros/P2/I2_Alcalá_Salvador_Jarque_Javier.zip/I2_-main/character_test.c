#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "character.h"
#include "character_test.h"
#include "test.h"

#define MAX_TESTS 30

int main(int argc, char** argv) {

  int test = 0;
  int all = 1;

  if (argc < 2) {
    printf("Running all test for module Character:\n");
  } else {
    test = atoi(argv[1]);
    all = 0;
    printf("Running test %d:\t", test);
    if (test < 1 && test > MAX_TESTS) {
      printf("Error: unknown test %d\t", test);
      exit(EXIT_SUCCESS);
    }
  }


if (all == 1 || test == 1) test1_character_create();
if (all == 1 || test == 2) test2_character_create();

if (all == 1 || test == 3) test1_character_get_id();
if (all == 1 || test == 4) test2_character_get_id();

if (all == 1 || test == 5) test1_character_set_id();
if (all == 1 || test == 6) test2_character_set_id();

if (all == 1 || test == 7) test1_character_set_name();
if (all == 1 || test == 8) test2_character_set_name();

if (all == 1 || test == 9) test1_character_get_name();
if (all == 1 || test == 10) test2_character_get_name();

if (all == 1 || test == 11) test1_character_set_gdesc();
if (all == 1 || test == 12) test2_character_set_gdesc();

if (all == 1 || test == 13) test1_character_get_gdesc();
if (all == 1 || test == 14) test2_character_get_gdesc();

if (all == 1 || test == 15) test1_character_set_health();
if (all == 1 || test == 16) test2_character_set_health();

if (all == 1 || test == 17) test1_character_get_health();
if (all == 1 || test == 18) test2_character_get_health();

if (all == 1 || test == 19) test1_character_set_friendly();
if (all == 1 || test == 20) test2_character_set_friendly();

if (all == 1 || test == 21) test1_character_get_friendly();
if (all == 1 || test == 22) test2_character_get_friendly();

if (all == 1 || test == 23) test1_character_set_message();
if (all == 1 || test == 24) test2_character_set_message();

if (all == 1 || test == 25) test1_character_get_message();
if (all == 1 || test == 26) test2_character_get_message();

  PRINT_PASSED_PERCENTAGE;

  return 0;
}

void test1_character_create() {
 int result;
  Character *p = character_create(1);
result=p!=NULL ;
  PRINT_TEST_RESULT(result);
  character_destroy(p);
}

void test2_character_create() { 
  PRINT_TEST_RESULT(character_create(NO_ID)==NULL);
}

void test1_character_get_id()
{
    Character *p = character_create(1);
  PRINT_TEST_RESULT(character_get_id(p) == 1);
  character_destroy(p);
}
void test2_character_get_id()
{
  PRINT_TEST_RESULT(character_get_id(NULL)==NO_ID);
}

void test1_character_set_id()
{
  Character *p = character_create(1);
  PRINT_TEST_RESULT(character_set_id(p,2) == OK);
  character_destroy(p);
}
void test2_character_set_id()
{
    Character *p = character_create(1);
  PRINT_TEST_RESULT(character_set_id(p,NO_ID) == ERROR);
  character_destroy(p);
}

void test1_character_set_name() {
  Character *p = character_create(1);
  PRINT_TEST_RESULT(character_set_name(p, "hola") == OK);
  character_destroy(p);
}
void test2_character_set_name() {
  Character *p = NULL;
 PRINT_TEST_RESULT(character_set_name(p, "hola") == ERROR);
}
void test1_character_get_name()
{
  Character *p = character_create(1);
  character_set_name(p, "hola");
  PRINT_TEST_RESULT( character_get_name(p)!=NULL);
  character_destroy(p);
}
void test2_character_get_name()
{
  Character *p = character_create(1);
  PRINT_TEST_RESULT( character_get_name(p)==NULL);
  character_destroy(p);
}

void test1_character_set_gdesc()
{
    Character *p = character_create(1);
  PRINT_TEST_RESULT( character_set_gdesc(p, "p")==OK);
  character_destroy(p);
}
void test2_character_set_gdesc()
{
      Character *p = character_create(1);
  PRINT_TEST_RESULT( character_set_gdesc(p, NULL)==ERROR);
  character_destroy(p);
}

void test1_character_get_gdesc()
{
    Character *p = character_create(1);
    character_set_gdesc(p, "p");
  PRINT_TEST_RESULT(character_get_gdesc(p)!=NULL);
  character_destroy(p);
}
void test2_character_get_gdesc()
{
 Character *p = character_create(1);
  PRINT_TEST_RESULT(character_get_gdesc(p)==NULL);
  character_destroy(p);
}

void test1_character_set_health() {
  Character *p = character_create(1);
  PRINT_TEST_RESULT(character_set_health(p, 100) == OK);
  character_destroy(p);
}

void test2_character_set_health() {
  Character *p = NULL;
  PRINT_TEST_RESULT(character_set_health(p, 100) == ERROR);
}

void test1_character_get_health()
{
    Character *p = character_create(1);
    character_set_health(p, 100);
  PRINT_TEST_RESULT(character_get_health(p)==OK);
  character_destroy(p);
}
void test2_character_get_health()
{
  PRINT_TEST_RESULT(character_get_health(NULL)==ERROR);
}

void test1_character_set_friendly() {
  Character *p = character_create(1);
    PRINT_TEST_RESULT(character_set_friendly(p, TRUE) == OK);
  character_destroy(p);
}

void test2_character_set_friendly() {
  Character *p = NULL;
  PRINT_TEST_RESULT(character_set_friendly(p, TRUE) == ERROR);
}

void test1_character_get_friendly()
{
  Character *p = character_create(1);
  character_set_friendly(p, TRUE);
  PRINT_TEST_RESULT(character_get_friendly(p)==TRUE);
  character_destroy(p);
}
void test2_character_get_friendly()
{
  PRINT_TEST_RESULT(character_get_friendly(NULL)==FALSE);
}

void test1_character_set_message() {
  Character *p = character_create(1);
 PRINT_TEST_RESULT(character_set_message(p, "blabla") == OK);
  character_destroy(p);
}

void test2_character_set_message() {
  Character *p = NULL;
  PRINT_TEST_RESULT(character_set_message(p, "blabla") == ERROR);
}

void test1_character_get_message()
{
    Character *p = character_create(1);
    character_set_message(p, "blabla");
 PRINT_TEST_RESULT( character_get_message(p)!=NULL);
  character_destroy(p);
}
void test2_character_get_message()
{
      Character *p = character_create(1);
 PRINT_TEST_RESULT( character_get_message(p)==NULL);
  character_destroy(p);
}

