/** 
 * @brief It declares the tests for the character module
 * 
 * @file character_test.h
 * @author Salvador Alcalá
 * @version 1.0 
 * @date 16-03-2026
 * @copyright GNU Public License
 */

#ifndef CHARACTER_TEST_H
#define CHARACTER_TEST_H

/**
 * @test Test character creation
 * @pre Character ID
 * @post Non NULL pointer to character
 */
void test1_character_create();

/**
 * @test Test character creation
 * @pre Character ID
 * @post Character_ID == Supplied Character Id
 */
void test2_character_create();

/**
 * @test Test function for character_get_id
 * @pre Valid character pointer
 * @post Output == Character id
 */
void test1_character_get_id();

/**
 * @test Test function for character_get_id
 * @pre Character pointer = NULL
 * @post Output == NULL
 */
void test2_character_get_id();

/**
 * @test Test function for character_id setting
 * @pre Valid character pointer and id
 * @post Output == OK
 */
void test1_character_set_id();

/**
 * @test Test function for character_id setting
 * @pre Character pointer = NULL
 * @post Output == ERROR
 */
void test2_character_set_id();

/**
 * @test Test function for character_name setting
 * @pre Valid character pointer and name string
 * @post Output == OK
 */
void test1_character_set_name();

/**
 * @test Test function for character_name setting
 * @pre Character pointer = NULL
 * @post Output == ERROR
 */
void test2_character_set_name();

/**
 * @test Test function for character_get_name
 * @pre Valid character pointer
 * @post Output == Character name
 */
void test1_character_get_name();

/**
 * @test Test function for character_get_name
 * @pre Character pointer = NULL
 * @post Output == NULL
 */
void test2_character_get_name();

/**
 * @test Test function for character_gdesc setting
 * @pre Valid character pointer and gdesc string
 * @post Output == OK
 */
void test1_character_set_gdesc();

/**
 * @test Test function for character_gdesc setting
 * @pre Character pointer = NULL
 * @post Output == ERROR
 */
void test2_character_set_gdesc();

/**
 * @test Test function for character_get_gdesc
 * @pre Valid character pointer
 * @post Output == Character gdesc
 */
void test1_character_get_gdesc();

/**
 * @test Test function for character_get_gdesc
 * @pre Character pointer = NULL
 * @post Output == NULL
 */
void test2_character_get_gdesc();

/**
 * @test Test function for character_health setting
 * @pre Valid character pointer and health value
 * @post Output == OK
 */
void test1_character_set_health();

/**
 * @test Test function for character_health setting
 * @pre Character pointer = NULL
 * @post Output == ERROR
 */
void test2_character_set_health();

/**
 * @test Test function for character_get_health
 * @pre Valid character pointer
 * @post Output == Character health
 */
void test1_character_get_health();

/**
 * @test Test function for character_get_health
 * @pre Character pointer = NULL
 * @post Output == -1
 */
void test2_character_get_health();

/**
 * @test Test function for character_friendly setting
 * @pre Valid character pointer and friendly value
 * @post Output == OK
 */
void test1_character_set_friendly();

/**
 * @test Test function for character_friendly setting
 * @pre Character pointer = NULL
 * @post Output == ERROR
 */
void test2_character_set_friendly();

/**
 * @test Test function for character_get_friendly
 * @pre Valid character pointer
 * @post Output == Character friendly value
 */
void test1_character_get_friendly();

/**
 * @test Test function for character_get_friendly
 * @pre Character pointer = NULL
 * @post Output == FALSE
 */
void test2_character_get_friendly();

/**
 * @test Test function for character_message setting
 * @pre Valid character pointer and message string
 * @post Output == OK
 */
void test1_character_set_message();

/**
 * @test Test function for character_message setting
 * @pre Character pointer = NULL
 * @post Output == ERROR
 */
void test2_character_set_message();

/**
 * @test Test function for character_get_message
 * @pre Valid character pointer
 * @post Output == Character message
 */
void test1_character_get_message();

/**
 * @test Test function for character_get_message
 * @pre Character pointer = NULL
 * @post Output == NULL
 */
void test2_character_get_message();

#endif