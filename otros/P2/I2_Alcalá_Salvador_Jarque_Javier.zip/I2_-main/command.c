/**
 * @brief It implements the command interpreter
 *
 * @file command.c
 * @author Teachers PPROG and Salvador Alcala
 * @version 1.3
 * @date 08-03-2026
 * @copyright GNU Public License
 */

#include "command.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define CMD_LENGHT 30

/**
 * @brief It defines the command strings
 *
 * This array stores the command strings for each command code.
 * The first column stores the long command string, and the second column stores the short command string.
 */
char *cmd_to_str[N_CMD][N_CMDT] = {{"", "No command"}, {"", "Unknown"}, {"e", "Exit"}, {"n", "Next"}, {"b", "Back"}, {"l", "Left"}, {"r", "Right"}, {"t", "Take"}, {"d", "Drop"}, {"a", "Attack"}, {"c", "Chat"}};

/**
 * @brief Command
 *
 * This struct stores all the information related to a command.
 */
struct _Command
{
  char *msg;        /*!< Message to be send*/
  CommandCode code; /*!< Name of the command */
};

/** space_create allocates memory for a new space
 *  and initializes its members
 */
Command *command_create()
{
  Command *newCommand = NULL;

  newCommand = (Command *)calloc(1, sizeof(Command));
  if (!newCommand)
  {
    return NULL;
  }

  /* Initialization of an empty command*/
  newCommand->code = NO_CMD;

  return newCommand;
}

void command_destroy(Command *command)
{
  if (command != NULL)
  {
    free(command);
  }
}

Status command_set_code(Command *command, CommandCode code)
{
  if (!command)
  {
    return ERROR;
  }

  command->code = code;

  return OK;
}

CommandCode command_get_code(Command *command)
{
  if (!command)
  {
    return NO_CMD;
  }
  return command->code;
}

char *command_get_msg(Command *command)
{
  if (!command)
  {
    return NULL;
  }
  return command->msg;
}

Status command_get_user_input(Command *command)
{
  char input[CMD_LENGHT] = "", *token = NULL;
  int i = UNKNOWN - NO_CMD + 1;
  CommandCode cmd;

  if (!command)
  {
    return ERROR;
  }

  if (command->msg != NULL)
  {
    free(command->msg);
    command->msg = NULL;
  }
  if (fgets(input, CMD_LENGHT, stdin))
  {

    token = strtok(input, " \n");
    if (!token)
    {
      return command_set_code(command, UNKNOWN);
    }

    cmd = UNKNOWN;
    while (cmd == UNKNOWN && i < N_CMD)
    {
      if (!strcasecmp(token, cmd_to_str[i][CMDS]) || !strcasecmp(token, cmd_to_str[i][CMDL]))
      {
        cmd = i + NO_CMD;
      }
      else
      {
        i++;
      }
    }
    if (cmd == CHAT||cmd == TAKE||cmd == DROP||cmd == ATTACK)
    {
      token = strtok(NULL, " \n");
      if (token != NULL)
      {
        command->msg = (char *)malloc((strlen(token) + 1) * sizeof(char));
        strcpy(command->msg, token);
      }
    }
    return command_set_code(command, cmd);
  }
  else
    return command_set_code(command, EXIT);
}
