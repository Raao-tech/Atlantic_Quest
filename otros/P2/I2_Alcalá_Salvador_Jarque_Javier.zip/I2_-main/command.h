/**
 * @brief It defines the command interpreter interface
 *
 * @file command.h
 * @author Teachers PPROG and Salvador Alcala
 * @version 1.3
 * @date 09-03-2026
 * @copyright GNU Public License
 */

#ifndef COMMAND_H
#define COMMAND_H

#include "types.h"

#define N_CMDT 2
#define N_CMD 11

typedef enum
{
    CMDS,
    CMDL
} CommandType;

typedef enum
{
    NO_CMD = -1,
    UNKNOWN,
    EXIT,
    NEXT,
    BACK,
    LEFT,
    RIGHT,
    TAKE,
    DROP,
    ATTACK,
    CHAT
} CommandCode;

typedef struct _Command Command;

/**
 * @brief It creates a new command struct, initializing the CommandCode variable code to NO_CMD
 * @author Profesores PPROG
 *
 * @return a new command, initialized
 */
Command *command_create();
/**
 * @brief It frees the memory allocated for a command struct
 * @author Profesores PPROG
 *
 * @param command the command to be destroyed
 */
void command_destroy(Command *command);
/**
 * @brief It updates the command->code based on the CommandCode variable introduced
 * @author Profesores PPROG
 *
 * @param command the command to be updated
 * @param code the CommandCode value to be set
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status command_set_code(Command *command, CommandCode code);
/**
 * @brief It gets the variable of type CommandCode stored in command->code
 * @author Profesores PPROG
 *
 * @param command the Command to get the code from
 * @return the CommandCode value stored in command->code, or NO_CMD if there was some mistake
 */
CommandCode command_get_code(Command *command);
/**
 * @brief It gets the variable message stored in command->code
 * @author Salvador Alcalá
 *
 * @param command the Command to get the message from
 * @return the message value stored in command->code, or NULL if there was some mistake
 */
char *command_get_msg (Command *command);
/**
 * @brief It gets the command introduced by the user based on their input and updates the command->code variable with the corresponding CommandCode value
 * @author Profesores PPROG
 *
 * @param command the Command to be modified with the user input
 * @return OK, if the CommandCode was updated successfully or ERROR if there was some mistake
 */
Status command_get_user_input(Command *command);

#endif
