/**
 * @brief It implements the game structure
 *
 * @file game.c
 * @author Teachers PPROG, Salvador Alcalá and Javier Jarque
 * @version 2.1
 * @date 13-03-2026
 * @copyright GNU Public License
 */

#include "game.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
   Game interface implementation
*/

struct Game_
{
  Player *player;                  /*!< Pointer to the player in the game*/
  Character *characters[MAX_CHAR]; /*!< Pointer to the character in the game*/
  Object *objects[MAX_OBJ];        /*!< Pointer to the object in the game*/
  Space *spaces[MAX_SPACES];       /*!< Array of pointers to the spaces in the game*/
  int n_spaces;                    /*!< Number of spaces stored in the game*/
  int n_characters;                /*!< Number of character stored in the game*/
  int n_objects;                   /*!< Number of objects stored in the game*/
  Command *last_cmd;               /*!< Pointer to the last command executed in the game*/
  Bool finished;                   /*!< Boolean value indicating if the game is finished or not*/
  char *message_to_print;          /*!< String for sending a message to print*/
};

Game *game_create()
{
  int i;

  Game *game = (Game *)calloc(1, sizeof(Game));
  /* Error control */
  if (!game)
  {
    return ERROR;
  }

  /* Initialization of the game */
  for (i = 0; i < MAX_SPACES; i++)
  {
    game->spaces[i] = NULL;
    game->objects[i] = NULL;
    game->characters[i] = NULL;
  }

  game->n_spaces = 0;
  game->player = NULL;
  game->message_to_print = NULL;
  game->last_cmd = command_create();
  if (!game->last_cmd)
  {
    return NULL;
  }
  game->finished = FALSE;

  return game;
}

void game_destroy(Game *game)
{
  int i = 0;

  if (game != NULL)
  {

    for (i = 0; i < game->n_spaces; i++)
    {
      if (game->spaces[i] != NULL)
      {
        space_destroy(game->spaces[i]);
      }
    }

    if (game->player != NULL)
    {
      player_destroy(game->player);
    }

    for (i = 0; i < game->n_objects; i++)
    {
      if (game->objects[i] != NULL)
      {
        object_destroy(game->objects[i]);
      }
    }

    for (i = 0; i < game->n_characters; i++)
    {
      if (game->characters[i] != NULL)
      {
        character_destroy(game->characters[i]);
      }
    }

    if (game->last_cmd != NULL)
    {
      command_destroy(game->last_cmd);
    }
    free(game);
  }
}

Space *game_get_space(Game *game, Id id)
{
  int i = 0;

  if (id == NO_ID || !game)
  {
    return NULL;
  }

  for (i = 0; i < game->n_spaces; i++)
  {
    if (id == space_get_id(game->spaces[i]))
    {
      return game->spaces[i];
    }
  }

  return NULL;
}

int Game_get_number_of_spaces(Game *g)
{
  if (!g)
  {
    return -1;
  }
  return g->n_spaces;
}

Player *game_get_player(Game *game)
{
  if (!game)
  {
    return NULL;
  }
  return game->player;
}

Object **game_get_objects(Game *game)
{
  if (!game)
  {
    return NULL;
  }
  return game->objects;
}

int Game_get_number_of_objects(Game *g)
{
  if (!g)
  {
    return -1;
  }
  return g->n_objects;
}

Object *game_get_object_from_id(Game *game, Id id)

{
  int i;
  if (!game)
  {
    return NULL;
  }

  for (i = 0; i < game->n_objects; i++)
  {
    if (id == object_get_id(game->objects[i]))
    {
      return game->objects[i];
    }
  }

  return NULL;
}

Object **game_get_objects_from_location(Game *game, Id id)
{
  Object **objects = NULL;
  Id *s = NULL;
  int i;
  if (!game || id < 0)
  {
    return NULL;
  }
  s = space_get_objects(game->spaces[id]);
  objects = (Object **)calloc(space_get_number_of_objects(game->spaces[id]), sizeof(Object **));
  if (!objects)
  {
    return NULL;
  }
  for (i = 0; i < space_get_number_of_objects(game->spaces[id]); i++)
  {
    if (game_get_object_from_id(game, s[i]) != NULL)
      objects[i] = game_get_object_from_id(game, s[i]);
    else
    {
      free(objects);
      return NULL;
    }
  }
  return objects;
}

Space *game_get_object_location(Game *game, Id id)
{
  Player *player = NULL;
  int bucle = 0;
  if (!game)
  {
    return NULL;
  }

  for (bucle = 0; bucle < game->n_spaces; bucle++)
  {
    if (space_find_object(game->spaces[bucle], id) == TRUE)
    {
      return game->spaces[bucle];
    }
  }
  player = game_get_player(game);
  if (!player)
  {
    return NULL;
  }

  if (player_find_object(player, id) == TRUE)
  {
    return NULL;
  }

  return NULL;
}

Character **game_get_characters(Game *game)
{
  if (!game)
  {
    return NULL;
  }
  return game->characters;
}

int Game_get_number_of_characters(Game *g)
{
  if (!g)
  {
    return -1;
  }
  return g->n_characters;
}

Space *game_get_character_location(Game *game, Id id)
{
  int bucle = 0;
  if (!game)
  {
    return NULL;
  }

  for (bucle = 0; bucle < game->n_spaces; bucle++)
  {
    if (space_find_character(game->spaces[bucle], id) == TRUE)
    {
      return game->spaces[bucle];
    }
  }

  return NULL;
}

Status game_set_player_location(Game *game, Id id)
{
  Player *player = NULL;
  if (id == NO_ID || !game)
  {
    return ERROR;
  }
  player = game_get_player(game);
  if (!player)
  {
    return ERROR;
  }
  player_set_location(player, id);

  return OK;
}

Character *game_get_character_from_id(Game *game, Id id)
{
  int i = 0;

  if (!game)
  {
    return NULL;
  }

  for (i = 0; i < game->n_characters; i++)
  {
    if (id == character_get_id(game->characters[i]))
    {
      return game->characters[i];
    }
  }

  return NULL;
}

Character **game_get_characters_from_location(Game *game, Id id)
{
  Character **characters = NULL;
  Id *s = NULL;
  int i;
  if (!game || id < 0)
  {
    return NULL;
  }
  s = space_get_characters(game->spaces[id]);
  characters = (Character **)calloc(space_get_number_of_characters(game->spaces[id]), sizeof(Character **));
  if (!characters)
  {
    return NULL;
  }
  for (i = 0; i < space_get_number_of_characters(game->spaces[id]); i++)
  {
    if (game_get_character_from_id(game, s[i]) != NULL)
      characters[i] = game_get_character_from_id(game, s[i]);
    else
    {
      free(characters);
      return NULL;
    }
  }
  return characters;
}

Command *game_get_last_command(Game *game)
{
  if (!game)
  {
    return NULL;
  }
  return game->last_cmd;
}

Status game_set_last_command(Game *game, Command *command)
{
  if (!game || !command)
  {
    return ERROR;
  }
  game->last_cmd = command;

  return OK;
}

Bool game_get_finished(Game *game)
{
  if (!game)
  {
    return FALSE;
  }
  return game->finished;
}

Status game_set_finished(Game *game, Bool finished)
{
  if (!game)
  {
    return ERROR;
  }
  game->finished = finished;

  return OK;
}

Status game_add_space(Game *game, Space *space)
{
  if ((space == NULL) || (game->n_spaces >= MAX_SPACES) || !game)
  {
    return ERROR;
  }

  game->spaces[game->n_spaces] = space;
  game->n_spaces++;

  return OK;
}
Status game_add_player(Game *game, Player *player)
{
  if (!player || !game)
  {
    return ERROR;
  }
  game->player = player;
  return OK;
}

Status game_add_object(Game *game, Object *object)
{
  if (!object || !game || game->n_objects >= MAX_OBJ)
  {
    return ERROR;
  }
  game->objects[game->n_objects] = object;
  game->n_objects++;
  return OK;
}

Status game_add_character(Game *game, Character *character)
{
  if (!character || !game || game->n_characters >= MAX_CHAR)
  {
    return ERROR;
  }
  game->characters[game->n_characters] = character;
  game->n_characters++;
  return OK;
}

Id game_get_space_id_at(Game *game, int position)
{
  if (position < 0 || position >= game->n_spaces || !game)
  {
    return NO_ID;
  }

  return space_get_id(game->spaces[position]);
}

Id game_find_object_name(Game *game, char *name)
{
  int loop;
  char *naux = NULL;
  if (!game || !name)
  {
    return NO_ID;
  }
  for (loop = 0; loop < game->n_objects; loop++)
  {
    naux = object_get_name(game->objects[loop]);
    if (strcmp(naux, name) == 0)
    {
      return object_get_id(game->objects[loop]);
    }
  }
  return NO_ID;
}

Id game_find_character_name(Game *game, char *name)
{
  int loop;
  char *naux = NULL;
  if (!game || !name)
  {
    return NO_ID;
  }
  for (loop = 0; loop < game->n_characters; loop++)
  {
    naux = character_get_name(game->characters[loop]);
    if (strcmp(naux, name) == 0)
    {
      return character_get_id(game->characters[loop]);
    }
  }
  return NO_ID;
}

char *game_get_message_to_print (Game *game)
{
  if(!game)
  {
    return NULL;
  }
  return game->message_to_print;
}

Status game_set_message_to_print (Game *game, char *msg)
{
  if(!game)
  {
    return ERROR;
  }

  game->message_to_print=msg;
  return OK;
}

void game_print(Game *game)
{
  Player *player = NULL;
  int i;
  i = 0;
  if (!game)
  {
    return;
  }

  printf("\n\n-------------\n\n");

  /* 1. Print the spaces stored*/
  printf("=> Spaces: \n");
  for (i = 0; i < game->n_spaces; i++)
  {
    space_print(game->spaces[i]);
  }

  /*2. Print the Ids from the player locations */

  player = game_get_player(game);
  if (!player)
  {
    return;
  }
  else
  {
     printf("=> Player location: %d\n", (int)player_get_location(player));
  }
  /*3. Print the id from the objets and characters locations */
  for (i = 0; i < game->n_objects; i++)
  {
    if (game->objects[i] != NULL)
    {
      printf("=> Objetc %s location: %d", object_get_name(game->objects[i]), (int)space_get_id(game_get_object_location(game, object_get_id(game->objects[i]))));
    }
  }
  for (i = 0; i < game->n_characters; i++)
  {
    if (game->characters[i] != NULL)
    {
      printf("=> Character %s location: %d", character_get_name(game->characters[i]), (int)space_get_id(game_get_character_location(game, character_get_id(game->characters[i]))));
    }
  }
}
