/**
 * @brief It defines the game interface
 *
 * @file game.h
 * @author Profesores PPROG, Salvador Alcalá y Javier Jarque
 * @version 1.6
 * @date 15-03-2026
 * @copyright GNU Public License
 */

#ifndef GAME_H
#define GAME_H

#include "command.h"
#include "space.h"
#include "types.h"
#include "player.h"
#include "character.h"

#define MAX_SPACES 100
#define MAX_OBJ 100
#define MAX_CHAR 100

/**
 * @brief Space
 *
 * This struct stores all the information of a game.
 */
typedef struct Game_ Game;

/**
 * @brief It creates a new game, allocating memory and initializing its members
 * @author Profesores PPROG
 *
 * @param game the game to be created
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Game *game_create();
/**
 * @brief It destroys a game, freeing the memory allocated for its members
 * @author Profesores PPROG
 *
 * @param game the game to be destroyed
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
void game_destroy(Game *game);
/**
 * @brief It gets a space stored in game
 * @author Profesores PPROG
 *
 * @param game the game to get the space from
 * @param id the id of the space to be retrieved
 * @return a pointer to the space, or NULL if there was some mistake
 */
Space *game_get_space(Game *game, Id id);

/**
 * @brief It gets the number of spaces stored in game
 * @author Salvador Alcalá
 *
 * @param game the game to get the number of spaces from
 * @return The number of spaces, or -1 if there was some mistake
 */
int Game_get_number_of_spaces(Game *g);

/**
 * @brief It gets the player stored in the game
 * @author Javier Jarque
 *
 * @param game a pointer to the game
 * @return the player of the game or NULL if was some mistake
 */
Player *game_get_player(Game *game);

/**
 * @brief It gets the list of objects stored in the game
 * @author Salvador Alcalá
 *
 * @param game a pointer to the game
 * @return the list of objects in the game or NULL if was some mistake
 */
Object **game_get_objects(Game *game);

/**
 * @brief It gets the number of objects stored in game
 * @author Salvador Alcalá
 *
 * @param game the game to get the number of spaces from
 * @return The number of objects, or -1 if there was some mistake
 */
int Game_get_number_of_objects(Game *g);

/**
 * @brief It gets the object using a id
 * @author Javier Jarque
 *
 * @param game a pointer to the game
 * @return a pointer to the object or NULL
 */
Object *game_get_object_from_id(Game *game, Id id);

/**
 * @brief It gets the objects from a location
 * @author Javier Jarque and Salvador Alcalá
 *
 * @param game the game to set the object in
 * @param id the id with the location of the object
 * @return a pointer to the objects if everything goes well or NULL if there was a mistake
 */
Object **game_get_objects_from_location(Game *game, Id id);

/**
 * @brief It gets the space that has the object
 * @author Javier Jarque and Salvador Alcalá
 *
 * @param game a pointer to the game
 * @param id id of the object to find
 * @return a pointer to the space that has the object or NULL
 */
Space *game_get_object_location(Game *game, Id id);

/**
 * @brief It gets the list of characters stored in the game
 * @author Salvador Alcalá
 *
 * @param game a pointer to the game
 * @return the list of characters in the game or NULL if was some mistake
 */
Character **game_get_characters(Game *game);

/**
 * @brief It gets the number of characters stored in game
 * @author Salvador Alcalá
 *
 * @param game the game to get the number of spaces from
 * @return The number of characters, or -1 if there was some mistake
 */
int Game_get_number_of_characters(Game *g);

/**
 * @brief It gets a characters from a location
 * @author Javier Jarque and Salvador Alcalá
 *
 * @param game the game to set the character in
 * @param id the id with the location of the character
 * @return a pointer to the list of characters it everything goes well or NULL if there was a mistake
 */
Character **game_get_characters_from_location(Game *game, Id id);

/**
 * @brief It gets the space that has the character
 * @author Javier Jarque and Salvador Alcalá
 *
 * @param game a pointer to the game
 * @param id id of the character to find
 * @return a pointer to the space that has the character or NULL
 */
Space *game_get_character_location(Game *game, Id id);

/**
 * @brief It sets the id of the space where the player is located
 * @author Profesores PPROG
 *
 * @param game the game to set the space in
 * @param id the id of the space where the player will be located
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status game_set_player_location(Game *game, Id id);

/**
 * @brief It gets the character using a location
 * @author Javier Jarque
 *
 * @param game the game to get the character in
 * @param id the id with the location of the character
 * @return a pointer to the character if everything goes well or NULL if there was a mistake
 */
Character *game_get_character_from_location (Game *game, Id id);

/**
 * @brief It gets the character using a id
 * @author Javier Jarque
 *
 * @param game the game to set the character in
 * @param id the id of the characteer
 * @return a pointer to the character it everything goes well or NULL if there was a mistake
 */
Character *game_get_character_from_id (Game *game, Id id);

/**
 * @brief It gets the last command executed in the game
 * @author Profesores PPROG
 *
 * @param game the game to get the command from
 * @return a pointer to the last command executed in the game, or NULL if there was some mistake
 */
Command *game_get_last_command(Game *game);
/**
 * @brief It updates the last command executed in the game
 * @author Profesores PPROG
 *
 * @param game the game to set the command in
 * @param command the command to be set as last command
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status game_set_last_command(Game *game, Command *command);
/**
 * @brief Checks if the game is finished or not
 * @author Profesores PPROG
 *
 * @param game the game to check if it is finished
 * @return TRUE if the game is finished, FALSE otherwise
 */
Bool game_get_finished(Game *game);
/**
 * @brief It sets the game as finished or not
 * @author Profesores PPROG
 *
 * @param game the game to set the boolean in
 * @param finished the value to set the game as finished or not
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status game_set_finished(Game *game, Bool finished);

/**
 * @brief It adds a space to the game and increments the number of spaces stored in the game
 * @author Teachers PPROG
 *
 * @param game the game to be modified
 * @param space the space to be added
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status game_add_space(Game *game, Space *space);
/**
 * @brief It adds a player to the game
 * @author Salvador Alcalá
 *
 * @param game the game to be modified
 * @param player the player to be added
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status game_add_player(Game *game, Player *player);
/**
 * @brief It adds an object to the game
 * @author Salvador Alcalá
 *
 * @param game the game to be modified
 * @param object the object to be added
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status game_add_object(Game *game, Object *object);

/**
 * @brief It adds a character to the game
 * @author Salvador Alcalá
 *
 * @param game the game to be modified
 * @param character the character to be added
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status game_add_character(Game *game, Character *character);

/**
 * @brief It gets the id of the space at a given position in the array of spaces stored in the game
 * @author Teachers PPROG
 *
 * @param game the game to get the space id from
 * @param position the position of the space in the array of spaces stored in the game
 * @return the id of the space at the given position or NO_ID if there was some mistake
 */
Id game_get_space_id_at(Game *game, int position);

/**
 * @brief It checks wether an object is present in the game or not
 * @author Salvador Alcalá
 *
 * @param game the game to get the object id from
 * @param name the name of the object to be found
 * @return the id of the object or NO_ID if there was some mistake
 */
Id game_find_object_name(Game *game, char *name);

/**
 * @brief It checks wether an character is present in the game or not
 * @author Salvador Alcalá
 *
 * @param game the game to get the object id from
 * @param name the name of the character to be found
 * @return the id of the character or NO_ID if there was some mistake
 */
Id game_find_character_name(Game *game, char *name);

/**
 * @brief It gets if there is a message to be printed
 * @author Salvador Alcalá
 *
 * @param game the game to set the boolean in
 * @return The message to be printed or NULL if there isn't any
 */
char *game_get_message_to_print (Game *game);

/**
 * @brief It sets a message to be printed
 * @author Salvador Alcalá
 *
 * @param game the game to set the boolean in
 * @param msg the message to be printed
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status game_set_message_to_print (Game *game, char *msg);

/**
 * @brief It prints the spaces, the location of the player and the location of the object in the game
 * @author Profesores PPROG
 *
 * @param game the game to be printed
 */
void game_print(Game *game);

#endif
