/**
 * @brief It implements the game update through user actions
 *
 * @file game_actions.c
 * @author Teachers PPROG and Salvador Alcala
 * @version 1.3
 * @date 08-03-2026
 * @copyright GNU Public License
 */

#include "game_actions.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/**
   Private functions
*/

void game_actions_next(Game *game);

void game_actions_back(Game *game);

void game_actions_left(Game *game);

void game_actions_right(Game *game);

void game_actions_take_object(Game *g, char *take);

void game_actions_drop_object(Game *g, char *drop);

void game_actions_attack(Game *game, char *attack);

char *game_actions_chat(Game *game, char *msg);
/**
   Game actions implementation
*/

Status game_actions_update(Game *game, Command *command)
{

  CommandCode cmd;
  char *msg = NULL, *print = NULL;
  if (!game || !command)
  {
    return ERROR;
  }
  game_set_last_command(game, command);

  cmd = command_get_code(command);

  switch (cmd)
  {
  case UNKNOWN:
    break;

  case EXIT:

    break;

  case NEXT:
    game_actions_next(game);
    break;

  case BACK:
    game_actions_back(game);
    break;

  case LEFT:
    game_actions_left(game);
    break;

  case RIGHT:

    game_actions_right(game);
    break;

  case TAKE:
    msg = command_get_msg(command);
    if (msg)
    {
      game_actions_take_object(game, msg);
    }
    break;

  case DROP:
    msg = command_get_msg(command);
    if (msg)
    {
      game_actions_drop_object(game, msg);
    }
    break;
  case ATTACK:
    msg = command_get_msg(command);
    if (msg)
    {
      game_actions_attack(game, msg);
    }
    break;

  case CHAT:
    msg = command_get_msg(command);
    if (msg)
    {
      print = game_actions_chat(game, msg);
      if (!print)
      {
        break;
      }
      game_set_message_to_print(game, print);
    }
    break;

  default:
    break;
  }

  return OK;
}

/**
   Calls implementation for each action
*/

void game_actions_next(Game *game)
{
  Id current_id = NO_ID;
  Id space_id = NO_ID;
  Player *player = NULL;
  Space *space = NULL;

  if (!game)
  {
    return;
  }
  player = game_get_player(game);
  if (!player)
  {
    return;
  }
  space_id = player_get_location(player);
  if (space_id == NO_ID)
  {
    return;
  }

  space = game_get_space(game, space_id);
  if (!space)
  {
    return;
  }
  current_id = space_get_south(space);
  if (current_id != NO_ID)
  {
    game_set_player_location(game, current_id);
  }

  return;
}

void game_actions_back(Game *game)
{
  Id current_id = NO_ID;
  Id space_id = NO_ID;
  Player *player = NULL;
  Space *space = NULL;

  if (!game)
  {
    return;
  }
  player = game_get_player(game);
  if (!player)
  {
    return;
  }
  space_id = player_get_location(player);

  if (NO_ID == space_id)
  {
    return;
  }
  space = game_get_space(game, space_id);
  if (!space)
  {
    return;
  }
  current_id = space_get_north(space);
  if (current_id != NO_ID)
  {
    game_set_player_location(game, current_id);
  }

  return;
}

void game_actions_left(Game *game)
{
  Id current_id = NO_ID;
  Id space_id = NO_ID;
  Player *player = NULL;
  Space *space = NULL;

  if (!game)
  {
    return;
  }
  player = game_get_player(game);
  if (!player)
  {
    return;
  }
  space_id = player_get_location(player);

  if (space_id == NO_ID)
  {
    return;
  }

  space = game_get_space(game, space_id);
  if (!space)
  {
    return;
  }

  current_id = space_get_west(space);
  if (current_id != NO_ID)
  {
    game_set_player_location(game, current_id);
  }
  return;
}

void game_actions_right(Game *game)
{
  Id current_id = NO_ID;
  Id space_id = NO_ID;
  Player *player = NULL;
  Space *space = NULL;

  if (!game)
  {
    return;
  }
  player = game_get_player(game);
  if (!player)
  {
    return;
  }
  space_id = player_get_location(player);
  if (space_id == NO_ID)
  {
    return;
  }
  space = game_get_space(game, space_id);
  if (!space)
  {
    return;
  }
  current_id = space_get_east(space);
  if (current_id != NO_ID)
  {
    game_set_player_location(game, current_id);
  }
  return;
}

void game_actions_take_object(Game *g, char *take)
{
  Player *player = NULL;
  Space *space = NULL;
  Space *obj_space = NULL;
  Id object = NO_ID;
  Id player_loc = NO_ID;
  if (!g || !take)
  {
    return;
  }
  player = game_get_player(g);
  if (!player)
  {
    return;
  }
  player_loc = player_get_location(player);
  if (player_loc == NO_ID)
  {
    return;
  }
  object = game_find_object_name(g, take);
  if (object == NO_ID)
  {
    return;
  }

  obj_space = game_get_object_location(g, object);
  if (!obj_space)
  {
    return;
  }

  if (space_get_id(obj_space) != player_loc)
  {
    return;
  }

  space = game_get_space(g, player_loc);
  if (!space)
  {
    return;
  }

  if (space_del_object(space, object) == ERROR)
  {
    return;
  }

  if (player_add_object(player, object) == ERROR)
  {
    space_add_object(space, object);
    return;
  }

  return;
}

void game_actions_drop_object(Game *g, char *drop)
{
  Space *space = NULL;
  Id player_loc = NO_ID;
  Player *player = NULL;
  Id object = NO_ID;

  if (!g || !drop)
  {
    return;
  }
  player = game_get_player(g);
  if (!player)
  {
    return;
  }
  player_loc = player_get_location(player);
  if (player_loc == NO_ID)
  {
    return;
  }
  object = game_find_object_name(g, drop);
  if (object == NO_ID)
  {
    return;
  }
  if (player_find_object(player, object) == FALSE)
  {
    return;
  }
  space = game_get_space(g, player_loc);
  if (!space)
  {
    return;
  }

  if (player_del_object(player, object) == ERROR)
  {
    return;
  }
  if (space_add_object(space, object) == ERROR)
  {
    return;
  }
  return;
}

void game_actions_attack(Game *game, char *attack)
{
  Player *player = NULL;
  Id player_loc = NO_ID;
  Id character;
  Id character_loc = NO_ID;
  Character *ch = NULL;

  srand(time(NULL));
  if (!game || !attack)
  {
    return;
  }
  player = game_get_player(game);
  if (!player)
  {
    return;
  }
  player_loc = player_get_location(player);
  if (player_loc == NO_ID)
  {
    return;
  }
  character = game_find_character_name(game, attack);
  if (character == NO_ID)
  {
    return;
  }
  ch = game_get_character_from_id(game, character);
  if (!ch)
  {
    return;
  }

  character_loc = space_get_id(game_get_character_location(game, character));
  if (player_loc != character_loc || character_get_health(ch) <= 0)
  {
    return;
  }

  if (character_get_friendly(ch) == FALSE || character_get_health(ch) > 0)
  {
    if ((rand() % 10) >= 5)
    {
      if (character_set_health(ch, character_get_health(ch) - 1) == ERROR)
      {
        return;
      }
    }
    else
    {
      if (player_set_health(player, player_get_health(player) - 1) == ERROR)
      {
        if (player_get_health(player) <= 0)
        {
          printf("  health: %d, GAME OVER!", player_get_health(player));
          game_set_finished(game, TRUE);
          return;
        }
      }
    }
    return;
  }
}

char *game_actions_chat(Game *game, char *chat)
{
  Player *player = NULL;
  Id player_loc = NO_ID;
  Id character;
  Id character_loc = NO_ID;
  Character *ch = NULL;

  if (!game || !chat)
  {
    return NULL;
  }
  player = game_get_player(game);
  if (!player)
  {
    return NULL;
  }
  player_loc = player_get_location(player);
  if (player_loc == NO_ID)
  {
    return NULL;
  }
  character = game_find_character_name(game, chat);
  if (character == NO_ID)
  {
    return NULL;
  }
  ch = game_get_character_from_id(game, character);
  if (!ch)
  {
    return NULL;
  }
  if (character_get_friendly(ch) == FALSE)
  {
    return NULL;
  }

  character_loc = space_get_id(game_get_character_location(game, character));
  if (player_loc != character_loc || character_get_health(ch) <= 0)
  {
    return NULL;
  }

  return character_get_message(ch);
}