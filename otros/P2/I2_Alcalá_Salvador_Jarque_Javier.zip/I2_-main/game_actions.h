/**
 * @brief It defines the game update interface
 *
 * @file game_actions.h
 * @author Profesores PPROG and Salvador Alcalá
 * @version 1.1
 * @date 08-03-2026
 * @copyright GNU Public License
 */

#ifndef GAME_ACTIONS_H
#define GAME_ACTIONS_H

#include "command.h"
#include "game.h"
#include "types.h"

/**
 * @brief It updates the game->command based on the user input
 * @author Profesores PPROG and Salvador Alcalá
 *
 * @param game the game to be updated
 * @param cmd the last command introduced by the user
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status game_actions_update(Game *game, Command *cmd);

#endif
