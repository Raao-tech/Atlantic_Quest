/**
 * @brief It defines the game loop
 *
 * @file game_loop.c
 * @author Teachers PPROG and Salvador Alcalá
 * @version  1
 * @date 14-02-2026
 * @copyright GNU Public License
 */

#include <stdio.h>
#include <stdlib.h>

#include "command.h"
#include "game.h"
#include "game_actions.h"
#include "graphic_engine.h"
#include "game_reader.h"

/**
 * Private functions
 */
Game *game_loop_init(Graphic_engine **gengine, char *file_name);

void game_loop_cleanup(Game *game, Graphic_engine *gengine);

/**
 * @brief Main function of the game loop and the entry point of the program
 * It initializes the game and the graphic engine, then it enters the main loop where it paints the game,
 * gets user input and updates the game until the user decides to exit or the game is finished.
 * Finally, it cleans up the resources used by the game and the graphic engine.
 * @author Teachers PPROG
 *
 * @param argc the number of arguments passed to the program
 * @param argv the array of arguments passed to the program, where argv[1] is the name of the file containing the game data
 * @return 0 if everything goes well, 1 if there was an error.
 */
int main(int argc, char *argv[])
{
  Game *game;
  Graphic_engine *gengine;
  Command *last_cmd;
  /**
   * Error control for the number of arguments.
   */
  if (argc < 2)
  {
    fprintf(stderr, "Use: %s <game_data_file>\n", argv[0]);
    return 1;
  }

  /* Initialize the game and the graphic engine */
  game = game_loop_init(&gengine, argv[1]);

  /*Error control*/
  if (!game)
  {
    fprintf(stderr, "Error while initializing game.\n");
    return 1;
  }
  else if (!gengine)
  {
    fprintf(stderr, "Error while initializing graphic engine.\n");
    return 1;
  }

  last_cmd = game_get_last_command(game);
  /* Game loop */
  while ((command_get_code(last_cmd) != EXIT) && (game_get_finished(game) == FALSE))
  {
    graphic_engine_paint_game(gengine, game);
    command_get_user_input(last_cmd);
    game_actions_update(game, last_cmd);
  }

  game_loop_cleanup(game, gengine);

  return 0;
}

/**
 * Private functions implementation
 */
Game *game_loop_init(Graphic_engine **gengine, char *file_name)
{
  Game *game;
  game = game_create_from_file(file_name);
  if (!game)
  {
    return NULL;
  }

  if ((*gengine = graphic_engine_create()) == NULL)
  {
    game_destroy(game);
    return NULL;
  }

  return game;
}

void game_loop_cleanup(Game *game, Graphic_engine *gengine)
{
  if (game != NULL)
  {
    game_destroy(game);
  }

  if (gengine != NULL)
  {
    graphic_engine_destroy(gengine);
  }
}
