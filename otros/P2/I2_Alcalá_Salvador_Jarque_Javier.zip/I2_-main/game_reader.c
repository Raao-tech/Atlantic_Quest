/**
 * @brief It implements the game reader
 *
 * @file game_reader.c
 * @author Salvador Alcalá y profesores PPROG
 * @version 1.7
 * @date 16-02-2026
 * @copyright GNU Public License
 */

#include "game_reader.h"

/*
Private functions
*/
/**
 * @brief It loads the spaces from the file and adds them to the game
 * @author Profesores PPROG and Salvador José Alcalá Álvarez
 *
 * @param game the struct where the data from the file will be loaded
 * @param filename the string which holds the name of the file that will be loaded (with extension)
 * @return status variable OK, if loaded succesfully, ERROR, if there was any problem
 */
Status game_load_spaces(Game *game, char *filename);
/**
 * @brief It loads the objects from the file and adds them to the game
 * @author Profesores PPROG and Salvador José Alcalá Álvarez
 *
 * @param game the struct where the data from the file will be loaded
 * @param filename the string which holds the name of the file that will be loaded (with extension)
 * @return status variable OK, if loaded succesfully, ERROR, if there was any problem
 */
Status game_load_objects(Game *game, char *filename);
/**
 * @brief It loads the characters from the file and adds them to the game
 * @author Profesores PPROG and Salvador José Alcalá Álvarez
 *
 * @param game the struct where the data from the file will be loaded
 * @param filename the string which holds the name of the file that will be loaded (with extension)
 * @return status variable OK, if loaded succesfully, ERROR, if there was any problem
 */
Status game_load_characters(Game *game, char *filename);
/**
 * @brief It loads the player from the file and sets it in the game
 * @author Profesores PPROG and Salvador José Alcalá Álvarez
 *
 * @param game the struct where the data from the file will be loaded
 * @param filename the string which holds the name of the file that will be loaded (with extension)
 * @return status variable OK, if loaded succesfully, ERROR, if there was any problem
 */
Status game_load_player(Game *game, char *filename);

/*
Loading from file implementation
*/

/**
 *Checks whether the game is able to create
 *a game, load it's spaces and set the player
 *and the object in the first space
 */
Game *game_create_from_file(char *filename)
{
    Game *game;
    game = game_create();
    printf("1. game creado\n");
    if (game == NULL)
    {
        return NULL;
    }
   if (game_load_spaces(game, filename) == ERROR)
    {
        game_destroy(game);
        return NULL;
    }
    printf("2. Espacios cargados\n");
    if (game_load_player(game, filename) == ERROR)
    {
        game_destroy(game);
        return NULL;
    }
    printf("3. Jugador creado\n");
    if (game_load_objects(game, filename) == ERROR)
    {
        game_destroy(game);
        return NULL;
    }
    printf("4. Objetos creados\n");
    if (game_load_characters(game, filename) == ERROR)
    {
        game_destroy(game);
        return NULL;
    }
    printf("5. Characters creados\n");

    return game;
}
/*
Private functions implementation
*/
/**
 *Opens the file and loads the spaces
 *based on the infromation from the file
 */
Status game_load_spaces(Game *game, char *filename)
{
    FILE *file = NULL;
    char line[WORD_SIZE] = "";
    char name[WORD_SIZE] = "";
    char *toks = NULL;
    char *gdesc[MAX_ROWS];
    int bucle, i;
    Id id = NO_ID, north = NO_ID, east = NO_ID, south = NO_ID, west = NO_ID;
    Space *space = NULL;
    Status status = OK;

    /*Error control*/
    if (!filename)
    {
        return ERROR;
    }

    file = fopen(filename, "r");
    if (file == NULL)
    {
        return ERROR;
    }

    /* Reading and loading spaces */
    while (fgets(line, WORD_SIZE, file))
    {
        line[strcspn(line, "\n")] = '\0';
        if (strncmp("#s:", line, 3) == 0)
        {
            toks = strtok(line + 3, "|");
            if (!toks)
            {
                printf("id\n");
                fclose(file);
                return ERROR;
            }

            id = atol(toks);

            toks = strtok(NULL, "|");
            if (!toks)
            {
                printf("name\n");
                fclose(file);
                return ERROR;
            }
            strncpy(name, toks, WORD_SIZE - 1);
            name[WORD_SIZE - 1] = '\0';

            if (strlen(name) > 0 && name[strlen(name) - 1] == '\n')
            {
                name[strlen(name) - 1] = '\0';
            }

            toks = strtok(NULL, "|");
            if (!toks)
            {

                fclose(file);
                return ERROR;
            }

            north = atol(toks);
            toks = strtok(NULL, "|");
            if (!toks)
            {
                fclose(file);
                return ERROR;
            }
            east = atol(toks);
            toks = strtok(NULL, "|");
            if (!toks)
            {
                fclose(file);
                return ERROR;
            }
            south = atol(toks);
            toks = strtok(NULL, "|");
            if (!toks)
            {
                fclose(file);
                return ERROR;
            }
            west = atol(toks);
#ifdef DEBUG
            printf("Leido: s:%ld|%s|%ld|%ld|%ld|%ld\n", id, name, north, east, south, west);
#endif
            for (bucle = 0; bucle < MAX_ROWS; bucle++)
            {
                gdesc[bucle] = (char *)calloc((MAX_COLUMNS + 1), sizeof(char));
                if (gdesc[bucle] == NULL)
                {
                    return ERROR;
                }
            }

            for (bucle = 0; bucle < MAX_ROWS; bucle++)
            {
                toks = strtok(NULL, "|");
                if (toks == NULL || strlen(toks) > MAX_COLUMNS)
                {
                    for (i = 0; i < bucle; i++)
                    {
                        free(gdesc[i]);
                    }
                    fclose(file);
                    return ERROR;
                }
                strncpy(gdesc[bucle], toks, MAX_COLUMNS);
                gdesc[bucle][MAX_COLUMNS] = '\0';
            }

            space = space_create(id);

            if (space != NULL)
            {
                if (space_set_gdesc(space, gdesc) == ERROR)
                {
                    for (bucle = 0; bucle < MAX_ROWS; bucle++)
                    {
                        free(gdesc[bucle]);
                    }
                }

                if (space_set_name(space, name) == ERROR ||
                    space_set_north(space, north) == ERROR ||
                    space_set_east(space, east) == ERROR ||
                    space_set_south(space, south) == ERROR ||
                    space_set_west(space, west) == ERROR)
                {
                    space_destroy(space);
                    return ERROR;
                }

                if (game_add_space(game, space) == ERROR)
                {
                    space_destroy(space);
                    return ERROR;
                }
            }
        }
    }

    if (ferror(file))
    {
        status = ERROR;
    }

    fclose(file);

    return status;
}

Status game_load_objects(Game *game, char *filename)
{
    FILE *file = NULL;
    Space *space_aux = NULL;
    Id id, object_space;
    Object *o = NULL;
    char name[WORD_SIZE];
    char *toks;
    char line[WORD_SIZE] = "";
    char *gdesc;
    /* Error control */
    if (!filename)
    {
        return ERROR;
    }
    if (!(file = fopen(filename, "r")))
    {
        return ERROR;
    }

    /* Reading and loading objects */
    while (fgets(line, WORD_SIZE, file))
    {
        if (strncmp(line, "#o:", 3) == 0)
        {
            toks = strtok(line + 3, "|");
            if (!toks)
            {
                fclose(file);
                return ERROR;
            }
            id = atol(toks);

            toks = strtok(NULL, "|");
            if (!toks)
            {
                fclose(file);
                return ERROR;
            }
            strncpy(name, toks, WORD_SIZE - 1);
            name[WORD_SIZE - 1] = '\0';
            toks = strtok(NULL, "|");
            if (!toks)
            {
                fclose(file);
                return ERROR;
            }
            object_space = atol(toks);

            toks = strtok(NULL, "|");
            if (!toks)
            {
                fclose(file);
                return ERROR;
            }

            if (strlen(toks) < 1)
            {
                fclose(file);
                return ERROR;
            }
            gdesc = (char *)calloc(strlen(toks) + 1, sizeof(char));
            if (!gdesc)
            {
                fclose(file);
                return ERROR;
            }

            strcpy(gdesc, toks);

            o = object_create(id);
            if (!o)
            {
                free(gdesc);
                fclose(file);
                return ERROR;
            }

            if (object_set_gdesc(o, gdesc) == ERROR || object_set_name(o, name) == ERROR)
            {
                free(gdesc);
                object_destroy(o);
                fclose(file);
                return ERROR;
            }
            space_aux = game_get_space(game, object_space);
            if (!space_aux)
            {
                object_destroy(o);
                fclose(file);
                return ERROR;
            }
            if (space_add_object(space_aux, id) == ERROR)
            {
                object_destroy(o);
                fclose(file);
                return ERROR;
            }
            if (game_add_object(game, o) == ERROR)
            {
                object_destroy(o);
                fclose(file);
                return ERROR;
            }
        }
    }

    if (ferror(file))
    {
        fclose(file);
        return ERROR;
    }
    fclose(file);
    return OK;
}

Status game_load_characters(Game *game, char *filename)
{
    FILE *file = NULL;
    Space *space_aux = NULL;
    Id id, character_space;
    Bool friendly = FALSE;
    Character *c = NULL;
    char *name = NULL;
    char *toks;
    char *gdesc = NULL;
    char *msg = NULL;
    char line[WORD_SIZE] = "";
    int health = 0;
    /* Error control */
    if (!filename)
    {
        return ERROR;
    }
    if (!(file = fopen(filename, "r")))
    {
        return ERROR;
    }

    /* Reading and loading objects */
    while (fgets(line, WORD_SIZE, file))
    {
        if (strncmp(line, "#c:", 3) == 0)
        {
            toks = strtok(line + 3, "|");
            if (!toks)
            {
                fclose(file);
                return ERROR;
            }
            id = atol(toks);
            toks = strtok(NULL, "|");
            if (!toks)
            {
                fclose(file);
                return ERROR;
            }
            name = (char *)malloc(strlen(toks) + 1);
            if (!name)
            {

                fclose(file);
                return ERROR;
            }
            strcpy(name, toks);
            toks = strtok(NULL, "|");
            if (!toks)
            {
                free(name);
                fclose(file);
                return ERROR;
            }
            character_space = atol(toks);

            toks = strtok(NULL, "|");
            if (!toks)
            {
                free(name);
                fclose(file);
                return ERROR;
            }

            if (strlen(toks) < 1)
            {
                free(name);
                fclose(file);
                return ERROR;
            }
            gdesc = (char *)calloc(strlen(toks) + 1, sizeof(char));
            if (!gdesc)
            {
                free(name);
                fclose(file);
                return ERROR;
            }
            strcpy(gdesc, toks);
            toks = strtok(NULL, "|");
            friendly = atoi(toks) != 0;

            toks = strtok(NULL, "|");
            if (!toks)
            {
                free(name);
                free(gdesc);
                fclose(file);
                return ERROR;
            }

            if (strlen(toks) < 1)
            {
                free(name);
                free(gdesc);
                fclose(file);
                return ERROR;
            }
            msg = (char *)calloc(strlen(toks) + 1, sizeof(char));
            if (!msg)
            {
                free(name);
                free(gdesc);
                fclose(file);
                return ERROR;
            }
            strcpy(msg, toks);

            toks = strtok(NULL, "|");
            if (!toks)
            {
                free(name);
                free(gdesc);
                free(msg);
                fclose(file);
                return ERROR;
            }
            health = atoi(toks);

            if (health < 1)
            {
                free(name);
                free(gdesc);
                free(msg);
                fclose(file);
                return ERROR;
            }

            c = character_create(id);
            if (!c)
            {
                free(name);
                free(gdesc);
                free(msg);
                fclose(file);
                return ERROR;
            }

            if (character_set_gdesc(c, gdesc) == ERROR || character_set_name(c, name) == ERROR || character_set_friendly(c, friendly) == ERROR || character_set_health(c, health) == ERROR || character_set_message(c, msg) == ERROR)
            {
                free(gdesc);
                free(msg);
                free(name);
                character_destroy(c);
                fclose(file);
                return ERROR;
            }
            free(name);
            space_aux = game_get_space(game, character_space);

            if (!space_aux)
            {
                character_destroy(c);
                fclose(file);
                return ERROR;
            }
            if (space_add_character(space_aux, id) == ERROR)
            {
                character_destroy(c);
                fclose(file);
                return ERROR;
            }
            if (game_add_character(game, c) == ERROR)
            {
                character_destroy(c);
                fclose(file);
                return ERROR;
            }
        }
    }

    if (ferror(file))
    {
        fclose(file);
        return ERROR;
    }
    fclose(file);
    return OK;
}

Status game_load_player(Game *game, char *filename)
{
    FILE *file = NULL;
    Player *p = NULL;
    Id id, player_space;
    char name[WORD_SIZE];
    char *toks;
    char *gdesc = NULL;
    char line[WORD_SIZE] = "";
    int health = 0;

    /* Error control */
    if (!filename)
    {
        return ERROR;
    }
    if (!(file = fopen(filename, "r")))
    {
        return ERROR;
    }

    /* Reading and loading player */
    while (fgets(line, WORD_SIZE, file))
    {
        if (strncmp(line, "#p:", 3) == 0)
        {
            toks = strtok(line + 3, "|");
            if (!toks)
            {
                fclose(file);
                return ERROR;
            }
            id = atol(toks);
            toks = strtok(NULL, "|");
            if (!toks)
            {
                fclose(file);
                return ERROR;
            }
            strncpy(name, toks, WORD_SIZE - 1);
            name[WORD_SIZE - 1] = '\0';
            toks = strtok(NULL, "|");
            if (!toks)
            {
                fclose(file);
                return ERROR;
            }
            player_space = atol(toks);
            toks = strtok(NULL, "|");
            if (!toks)
            {
                fclose(file);
                return ERROR;
            }

            if (strlen(toks) < 1)
            {
                fclose(file);
                return ERROR;
            }
            gdesc = (char *)calloc(strlen(toks) + 1, sizeof(char));
            if (!gdesc)
            {
                fclose(file);
                return ERROR;
            }
            strcpy(gdesc, toks);

            toks = strtok(NULL, "|");
            if (!toks)
            {
                free(gdesc);
                fclose(file);
                return ERROR;
            }
            health = atoi(toks);

            if (health < 1)
            {
                free(gdesc);
                fclose(file);
                return ERROR;
            }

            p = player_create(id);
            if (!p)
            {
                free(gdesc);
                fclose(file);
                return ERROR;
            }

            if (player_set_name(p, name) == ERROR || player_set_gdesc(p, gdesc) == ERROR || player_set_health(p, health) == ERROR)
            {
                player_destroy(p);
                free(gdesc);
                fclose(file);
                return ERROR;
            }
            if (game_add_player(game, p) == ERROR)
            {
                player_destroy(p);
                fclose(file);
                return ERROR;
            }
            if (game_set_player_location(game, player_space) == ERROR)
            {
                player_destroy(p);
                fclose(file);
                return ERROR;
            }
        }
    }

    if (ferror(file))
    {
        fclose(file);
        return ERROR;
    }
    fclose(file);
    return OK;
}
