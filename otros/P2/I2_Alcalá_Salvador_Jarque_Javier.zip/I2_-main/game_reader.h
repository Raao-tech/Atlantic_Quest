/**
 * @brief It defines the game reader interface
 *
 * @file game_reader.h
 * @author Salvador Alcalá y profesores PPROG
 * @version 1.1
 * @date 03-02-2026
 * @copyright GNU Public License
 */
#ifndef GAME_READER_H
#define GAME__READER_H

#include "game.h"
#include "player.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/**
 * @brief It creates a game from a file, loading the spaces and the object where hte file says
 * @author Profesores PPROG, Salvador José Alcalá Álvarez and Javier Jarque Narro
 *
 * @param filename the string which holds the name of the file that will be loaded (with extension)
 * @return game if loaded succesfully, NULL if there was any problem
 */
Game *game_create_from_file(char *filename);

#endif