/**
 * @brief It implements a textual graphic engine
 *
 * @file graphic_engine.c
 * @author Teachers PPROG and Salvador Alcalá
 * @version 1.7
 * @date 08-03-2026
 * @copyright GNU Public License
 */

#include "graphic_engine.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "command.h"
#include "libscreen.h"
#include "space.h"
#include "types.h"
#include "set.h"

#define WIDTH_MAP 80
#define WIDTH_DES 48
#define WIDTH_BAN 25 * 3
#define HEIGHT_MAP 40
#define HEIGHT_BAN 1
#define HEIGHT_HLP 2
#define HEIGHT_FDB 3

/**
 * @brief Graphic_engine
 *
 * This struct stores all the information of the graphic engine.
 */
struct _Graphic_engine
{
  Area *map;      /*!< Pointer to the area of the map */
  Area *descript; /*!< Pointer to the area of the description */
  Area *banner;   /*!< Pointer to the area of the banner */
  Area *help;     /*!< Pointer to the area of the help */
  Area *feedback; /*!< Pointer to the area of the feedback */
};

/** graphic_engine_create allocates memory for a new graphic engine
 *  and initializes its members
 */
Graphic_engine *graphic_engine_create()
{
  static Graphic_engine *ge = NULL;

  if (ge != NULL)
  {
    return ge;
  }

  /*Creates the screen*/
  screen_init(HEIGHT_MAP + HEIGHT_BAN + HEIGHT_HLP + HEIGHT_FDB + 4, WIDTH_MAP + WIDTH_DES + 3);
  ge = (Graphic_engine *)calloc(1, sizeof(Graphic_engine));

  /* Error control */
  if (!ge)
  {
    return NULL;
  }

  /* Initialization of the graphic engine areas */
  ge->map = screen_area_init(1, 1, WIDTH_MAP, HEIGHT_MAP);
  ge->descript = screen_area_init(WIDTH_MAP + 2, 1, WIDTH_DES, HEIGHT_MAP);
  ge->banner = screen_area_init((int)((WIDTH_MAP + WIDTH_DES + 1 - WIDTH_BAN) / 2), HEIGHT_MAP + 2, WIDTH_BAN, HEIGHT_BAN);
  ge->help = screen_area_init(1, HEIGHT_MAP + HEIGHT_BAN + 2, WIDTH_MAP + WIDTH_DES + 1, HEIGHT_HLP);
  ge->feedback = screen_area_init(1, HEIGHT_MAP + HEIGHT_BAN + HEIGHT_HLP + 3, WIDTH_MAP + WIDTH_DES + 1, HEIGHT_FDB);

  return ge;
}

void graphic_engine_destroy(Graphic_engine *ge)
{
  if (!ge)
    return;

  screen_area_destroy(ge->map);
  screen_area_destroy(ge->descript);
  screen_area_destroy(ge->banner);
  screen_area_destroy(ge->help);
  screen_area_destroy(ge->feedback);

  screen_destroy();
  free(ge);
}

void graphic_engine_paint_game(Graphic_engine *ge, Game *game)
{
  Id id_act = NO_ID, id_back = NO_ID, id_next = NO_ID, id_left = NO_ID, id_right = NO_ID;
  Id *objs_in_act = NULL, *objs_in_south = NULL, *objs_in_west = NULL, *objs_in_east = NULL, *objs_in_north = NULL;
  Id *chars_in_act = NULL, *chars_in_south = NULL, *chars_in_west = NULL, *chars_in_east = NULL, *chars_in_north = NULL;
  Id *player_objs = NULL;
  Space *space_act = NULL, *space_back = NULL, *space_next = NULL, *space_left = NULL, *space_right = NULL;
  char str[512];
  char *gdesc_p = NULL, **gdesc_act, **gdesc_back, **gdesc_next, **gdesc_left, **gdesc_right;
  char *gdesc_obj_act[MAX_OBJ_TO_SHOW], *gdesc_obj_back[MAX_OBJ_TO_SHOW], *gdesc_obj_next[MAX_OBJ_TO_SHOW], *gdesc_obj_left[MAX_OBJ_TO_SHOW], *gdesc_obj_right[MAX_OBJ_TO_SHOW];
  char *gdesc_char_act, *gdesc_char_back, *gdesc_char_next, *gdesc_char_left, *gdesc_char_right;
  char *msg = NULL;
  Player *player = NULL;
  Object **objects = NULL;
  Character **Characters = NULL;
  int player_health = 0, bucle, n_objs;
  CommandCode last_cmd = UNKNOWN;
  extern char *cmd_to_str[N_CMD][N_CMDT];

  if (!ge || !game)
  {

    game_set_finished(game, TRUE);
    return;
  }
  /* Paint the in the map area */
  screen_area_clear(ge->map);

  player = game_get_player(game);
  if (!player)
  {
    game_set_finished(game, TRUE);
    return;
  }

  gdesc_p = player_get_gdesc(player);
  if (!gdesc_p)
  {
    game_set_finished(game, TRUE);
    return;
  }

  player_health = player_get_health(player);
  if (player_health <= 0)
  {

    game_set_finished(game, TRUE);
    return;
  }

  if ((id_act = player_get_location(player)) != NO_ID)
  {
    space_act = game_get_space(game, id_act);
    if (!space_act)
    {

      game_set_finished(game, TRUE);
      return;
    }
    gdesc_act = space_get_gdesc(space_act);

    objs_in_act = space_get_objects(space_act);
    n_objs = space_get_number_of_objects(space_act);

    for (bucle = 0; bucle < MAX_OBJ_TO_SHOW; bucle++)
    {
      if (bucle < n_objs)
      {
        gdesc_obj_act[bucle] =
            object_get_gdesc(game_get_object_from_id(game, objs_in_act[bucle]));
      }
      else
      {
        gdesc_obj_act[bucle] = NULL;
      }
    }

    id_back = space_get_north(space_act);
    id_next = space_get_south(space_act);
    id_left = space_get_west(space_act);
    id_right = space_get_east(space_act);

    chars_in_act = space_get_characters(space_act);
    if (space_get_number_of_characters(space_act) > 0 && chars_in_act)
    {
      gdesc_char_act = character_get_gdesc(
          game_get_character_from_id(game, chars_in_act[0]));
    }
    else
    {
      gdesc_char_act = NULL;
    }

    if (id_back != NO_ID)
    {
      space_back = game_get_space(game, id_back);
      if (!space_back)
      {

        game_set_finished(game, TRUE);
        return;
      }
      gdesc_back = space_get_gdesc(space_back);

      chars_in_north = space_get_characters(space_back);
      if (space_get_number_of_characters(space_back) > 0 && chars_in_north)
      {
        gdesc_char_back = character_get_gdesc(game_get_character_from_id(game, chars_in_north[0]));
      }
      else
      {
        gdesc_char_back = NULL;
      }

      objs_in_north = space_get_objects(space_back);
      n_objs = space_get_number_of_objects(space_back);

      for (bucle = 0; bucle < MAX_OBJ_TO_SHOW; bucle++)
      {
        if (bucle < n_objs)
        {
          gdesc_obj_back[bucle] =
              object_get_gdesc(game_get_object_from_id(game, objs_in_north[bucle]));
        }
        else
        {
          gdesc_obj_back[bucle] = NULL;
        }
      }
    }

    if (id_left != NO_ID)
    {
      space_left = game_get_space(game, id_left);
      if (!space_left)
      {

        game_set_finished(game, TRUE);
        return;
      }
      gdesc_left = space_get_gdesc(space_left);

      chars_in_west = space_get_characters(space_left);
      if (space_get_number_of_characters(space_left) > 0 && chars_in_west)
      {
        gdesc_char_left = character_get_gdesc(
            game_get_character_from_id(game, chars_in_west[0]));
      }
      else
      {
        gdesc_char_left = NULL;
      }

      objs_in_west = space_get_objects(space_left);
      n_objs = space_get_number_of_objects(space_left);

      for (bucle = 0; bucle < MAX_OBJ_TO_SHOW; bucle++)
      {
        if (bucle < n_objs)
        {
          gdesc_obj_left[bucle] =
              object_get_gdesc(game_get_object_from_id(game, objs_in_west[bucle]));
        }
        else
        {
          gdesc_obj_left[bucle] = NULL;
        }
      }
    }

    if (id_right != NO_ID)
    {
      space_right = game_get_space(game, id_right);
      if (!space_right)
      {

        game_set_finished(game, TRUE);
        return;
      }
      gdesc_right = space_get_gdesc(space_right);

      chars_in_east = space_get_characters(space_right);
      if (space_get_number_of_characters(space_right) > 0 && chars_in_east)
      {
        gdesc_char_right = character_get_gdesc(
            game_get_character_from_id(game, chars_in_east[0]));
      }
      else
      {
        gdesc_char_right = NULL;
      }

      objs_in_east = space_get_objects(space_right);
      n_objs = space_get_number_of_objects(space_right);

      for (bucle = 0; bucle < MAX_OBJ_TO_SHOW; bucle++)
      {
        if (bucle < n_objs)
        {
          gdesc_obj_right[bucle] =
              object_get_gdesc(game_get_object_from_id(game, objs_in_east[bucle]));
        }
        else
        {
          gdesc_obj_right[bucle] = NULL;
        }
      }
    }

    if (id_next != NO_ID)
    {
      space_next = game_get_space(game, id_next);
      if (!space_next)
      {
        game_set_finished(game, TRUE);
        return;
      }
      gdesc_next = space_get_gdesc(space_next);

      chars_in_south = space_get_characters(space_next);
      if (space_get_number_of_characters(space_next) > 0 && chars_in_south)
      {
        gdesc_char_next = character_get_gdesc(
            game_get_character_from_id(game, chars_in_south[0]));
      }
      else
      {
        gdesc_char_next = NULL;
      }

      objs_in_south = space_get_objects(space_next);
      n_objs = space_get_number_of_objects(space_next);

      for (bucle = 0; bucle < MAX_OBJ_TO_SHOW; bucle++)
      {
        if (bucle < n_objs)
        {
          gdesc_obj_next[bucle] =
              object_get_gdesc(game_get_object_from_id(game, objs_in_south[bucle]));
        }
        else
        {
          gdesc_obj_next[bucle] = NULL;
        }
      }
    }

    /* Room behind */
    if (id_back != NO_ID)
    {
      sprintf(str, "                     +---------------+                   ");
      screen_area_puts(ge->map, str);
      sprintf(str, "                     |%6s%4s%5d|                     ",
              "      ", gdesc_char_back ? gdesc_char_back : "    ", (int)id_back);
      screen_area_puts(ge->map, str);
      for (bucle = 0; bucle < MAX_ROWS; bucle++)
      {
        if (gdesc_back[bucle])
        {
          sprintf(str, "                     |%9s      |                     ",
                  gdesc_back[bucle] ? gdesc_back[bucle] : "         ");
          screen_area_puts(ge->map, str);
        }
      }
      sprintf(str, "                     |%1s      %1s      %1s|               ",
              gdesc_obj_back[0] ? gdesc_obj_back[0] : " ", gdesc_obj_back[1] ? gdesc_obj_back[1] : " ", gdesc_obj_back[2] ? gdesc_obj_back[2] : " ");
      screen_area_puts(ge->map, str);
      sprintf(str, "                     +---------------+               ");
      screen_area_puts(ge->map, str);
      sprintf(str, "                             ^                   ");
      screen_area_puts(ge->map, str);
    }

    /* Current room */
    if (id_left == NO_ID && id_right == NO_ID)
    {
      sprintf(str, "                     +---------------+                   ");
      screen_area_puts(ge->map, str);
      sprintf(str, "                     |%-6s%4s%5d|                     ",
              gdesc_p, gdesc_char_act ? gdesc_char_act : "    ", (int)id_act);
      screen_area_puts(ge->map, str);
      for (bucle = 0; bucle < MAX_ROWS; bucle++)
      {
        sprintf(str, "                     |%-9s      |                     ",
                gdesc_act[bucle] ? gdesc_act[bucle] : "         ");
        screen_area_puts(ge->map, str);
      }
      sprintf(str, "                     |%1s      %1s      %1s|               ",
              gdesc_obj_act[0] ? gdesc_obj_act[0] : " ", gdesc_obj_act[1] ? gdesc_obj_act[1] : " ", gdesc_obj_act[2] ? gdesc_obj_act[2] : " ");
      screen_area_puts(ge->map, str);
      sprintf(str, "                     +---------------+               ");
      screen_area_puts(ge->map, str);
    }
    /* Left room + Current room + Right room */
    else if (id_left != NO_ID && id_right != NO_ID)
    {
      sprintf(str, "  +---------------+  +---------------+  +---------------+ ");
      screen_area_puts(ge->map, str);
      sprintf(str, "  |%6s%4s%5d|  |%-6s%4s%5d|  |%6s%4s%5d| ",
              "      ", gdesc_char_left ? gdesc_char_left : "    ", (int)id_left,
              gdesc_p, gdesc_char_act ? gdesc_char_act : "    ", (int)id_act,
              "      ", gdesc_char_right ? gdesc_char_right : "    ", (int)id_right);
      screen_area_puts(ge->map, str);
      for (bucle = 0; bucle < MAX_ROWS; bucle++)
      {
        sprintf(str, "  |%-9s      |  |%-9s      |  |%-9s      | ",
                gdesc_left[bucle] ? gdesc_left[bucle] : "         ",
                gdesc_act[bucle] ? gdesc_act[bucle] : "         ",
                gdesc_right[bucle] ? gdesc_right[bucle] : "         ");
        screen_area_puts(ge->map, str);
      }
      sprintf(str, "  |%1s      %1s      %1s| <|%1s      %1s      %1s|> |%1s      %1s      %1s| ",
              gdesc_obj_left[0] ? gdesc_obj_left[0] : " ", gdesc_obj_left[1] ? gdesc_obj_left[1] : " ", gdesc_obj_left[2] ? gdesc_obj_left[2] : " ",
              gdesc_obj_act[0] ? gdesc_obj_act[0] : " ", gdesc_obj_act[1] ? gdesc_obj_act[1] : " ", gdesc_obj_act[2] ? gdesc_obj_act[2] : " ",
              gdesc_obj_right[0] ? gdesc_obj_right[0] : " ", gdesc_obj_right[1] ? gdesc_obj_right[1] : " ", gdesc_obj_right[2] ? gdesc_obj_right[2] : " ");
      screen_area_puts(ge->map, str);
      sprintf(str, "  +---------------+  +---------------+  +---------------+ ");
      screen_area_puts(ge->map, str);
    }
    /*Left room + Current room*/
    else if (id_left != NO_ID && id_right == NO_ID)
    {
      sprintf(str, "  +---------------+  +---------------+                    ");
      screen_area_puts(ge->map, str);
      sprintf(str, "  |%6s%4s%5d|  |%-6s%4s%5d|                    ",
              "      ", gdesc_char_left ? gdesc_char_left : "    ", (int)id_left,
              gdesc_p, gdesc_char_act ? gdesc_char_act : "    ", (int)id_act);
      screen_area_puts(ge->map, str);
      for (bucle = 0; bucle < MAX_ROWS; bucle++)
      {
        sprintf(str, "  |%-9s      |  |%-9s      |                    ",
                gdesc_left[bucle] ? gdesc_left[bucle] : "         ",
                gdesc_act[bucle] ? gdesc_act[bucle] : "         ");
        screen_area_puts(ge->map, str);
      }
      sprintf(str, "  |%1s      %1s      %1s| <|%1s      %1s      %1s|                    ",
              gdesc_obj_left[0] ? gdesc_obj_left[0] : " ", gdesc_obj_left[1] ? gdesc_obj_left[1] : " ", gdesc_obj_left[2] ? gdesc_obj_left[2] : " ",
              gdesc_obj_act[0] ? gdesc_obj_act[0] : " ", gdesc_obj_act[1] ? gdesc_obj_act[1] : " ", gdesc_obj_act[2] ? gdesc_obj_act[2] : " ");
      screen_area_puts(ge->map, str);
      sprintf(str, "  +---------------+  +---------------+                    ");
      screen_area_puts(ge->map, str);
    }
    /*Current room + right room*/
    else if (id_right != NO_ID && id_left == NO_ID)
    {
      sprintf(str, "                     +---------------+  +---------------+ ");
      screen_area_puts(ge->map, str);
      sprintf(str, "                     |%-6s%4s%5d|  |%6s%4s%5d| ",
              gdesc_p, gdesc_char_act ? gdesc_char_act : "    ", (int)id_act,
              "      ", gdesc_char_right ? gdesc_char_right : "    ", (int)id_right);
      screen_area_puts(ge->map, str);
      for (bucle = 0; bucle < MAX_ROWS; bucle++)
      {
        sprintf(str, "                     |%-9s      |  |%-9s      | ",
                gdesc_act[bucle] ? gdesc_act[bucle] : "         ",
                gdesc_right[bucle] ? gdesc_right[bucle] : "         ");
        screen_area_puts(ge->map, str);
      }
      sprintf(str, "                     |%1s      %1s      %1s|> |%1s      %1s      %1s| ",
              gdesc_obj_act[0] ? gdesc_obj_act[0] : " ", gdesc_obj_act[1] ? gdesc_obj_act[1] : " ", gdesc_obj_act[2] ? gdesc_obj_act[2] : " ",
              gdesc_obj_right[0] ? gdesc_obj_right[0] : " ", gdesc_obj_right[1] ? gdesc_obj_right[1] : " ", gdesc_obj_right[2] ? gdesc_obj_right[2] : " ");
      screen_area_puts(ge->map, str);
      sprintf(str, "                     +---------------+  +---------------+ ");
      screen_area_puts(ge->map, str);
    }

    /* Next room*/
    if (id_next != NO_ID)
    {
      sprintf(str, "                             v                   ");
      screen_area_puts(ge->map, str);
      sprintf(str, "                     +---------------+                   ");
      screen_area_puts(ge->map, str);
      sprintf(str, "                     |%6s%4s%5d|                     ",
              "      ", gdesc_char_next ? gdesc_char_next : "    ", (int)id_next);
      screen_area_puts(ge->map, str);
      for (bucle = 0; bucle < MAX_ROWS; bucle++)
      {
        sprintf(str, "                     |%-9s      |                     ",
                gdesc_next[bucle] ? gdesc_next[bucle] : "         ");
        screen_area_puts(ge->map, str);
      }
      sprintf(str, "                     |%1s      %1s      %1s|               ",
              gdesc_obj_next[0] ? gdesc_obj_next[0] : " ", gdesc_obj_next[1] ? gdesc_obj_next[1] : " ", gdesc_obj_next[2] ? gdesc_obj_next[2] : " ");
      screen_area_puts(ge->map, str);
      sprintf(str, "                     +---------------+               ");
      screen_area_puts(ge->map, str);
    }

    /* Paint in the description area */
    screen_area_clear(ge->descript);

    sprintf(str, " Number of spaces: %d", Game_get_number_of_spaces(game));
    screen_area_puts(ge->descript, str);
    objects = game_get_objects(game);
    sprintf(str, "  Objects:");
    screen_area_puts(ge->descript, str);
    if (objects)
    {
      for (bucle = 0; bucle < Game_get_number_of_objects(game); bucle++)
      {
        if ((int)space_get_id(game_get_object_location(game, object_get_id(objects[bucle]))) != NO_ID)
        {
          sprintf(str, "    %s  :  %d", object_get_name(objects[bucle]), (int)space_get_id(game_get_object_location(game, object_get_id(objects[bucle]))));
          screen_area_puts(ge->descript, str);
        }
        else
        {
          sprintf(str, "    %s  :  WITH PLAYER", object_get_name(objects[bucle]));
          screen_area_puts(ge->descript, str);
        }
      }
    }

    sprintf(str, "  ");
    screen_area_puts(ge->descript, str);
    Characters = game_get_characters(game);
    sprintf(str, "  Characters:");
    screen_area_puts(ge->descript, str);
    if (Characters)
    {
      for (bucle = 0; bucle < Game_get_number_of_characters(game); bucle++)
      {
        if (character_get_friendly(Characters[bucle]) == TRUE)
        {
          if (character_get_health(Characters[bucle]) > 0)
          {
            sprintf(str, "   %s (%s) (Friendly)  :  %d (%d)", character_get_gdesc(Characters[bucle]), character_get_name(Characters[bucle]), (int)space_get_id(game_get_character_location(game, character_get_id(Characters[bucle]))), character_get_health(Characters[bucle]));
            screen_area_puts(ge->descript, str);
          }
          else
          {
            sprintf(str, "   %s (%s) (Friendly) :  %d (%d, dead)", character_get_gdesc(Characters[bucle]), character_get_name(Characters[bucle]), (int)space_get_id(game_get_character_location(game, character_get_id(Characters[bucle]))), character_get_health(Characters[bucle]));
            screen_area_puts(ge->descript, str);
          }
        }
        else
        {
          if (character_get_health(Characters[bucle]) > 0)
          {
            sprintf(str, "   %s (%s) (Enemy)  :  %d (%d)", character_get_gdesc(Characters[bucle]), character_get_name(Characters[bucle]), (int)space_get_id(game_get_character_location(game, character_get_id(Characters[bucle]))), character_get_health(Characters[bucle]));
            screen_area_puts(ge->descript, str);
          }
          else
          {
            sprintf(str, "   %s (%s) (Enemy) :  %d (%d, dead)", character_get_gdesc(Characters[bucle]), character_get_name(Characters[bucle]), (int)space_get_id(game_get_character_location(game, character_get_id(Characters[bucle]))), character_get_health(Characters[bucle]));
            screen_area_puts(ge->descript, str);
          }
        }
      }
    }

    sprintf(str, "  ");
    screen_area_puts(ge->descript, str);
    sprintf(str, "  Player:");
    screen_area_puts(ge->descript, str);
    if (player_health <= 2 && player_health > 0)
    {
      sprintf(str, "   health: %d (Critical)", player_health);
      screen_area_puts(ge->descript, str);
    }

    else if (player_health > 2)
    {
      sprintf(str, "  health: %d", player_health);
      screen_area_puts(ge->descript, str);
    }
    else if (player_health <= 0)
    {
      printf("  health: %d, GAME OVER!", player_health);
      game_set_finished(game, TRUE);
    }
    sprintf(str, "  ");
    screen_area_puts(ge->descript, str);

    player_objs = player_get_objects(player);
    if (player_get_number_of_objects(player) == 0)
    {
      sprintf(str, "  Player has no objects");
      screen_area_puts(ge->descript, str);
    }

    else
    {
      for (bucle = 0; bucle < player_get_number_of_objects(player); bucle++)
      {
        sprintf(str, "   %s (%s) ", object_get_gdesc(game_get_object_from_id(game, player_objs[bucle])), object_get_name(game_get_object_from_id(game, player_objs[bucle])));
        screen_area_puts(ge->descript, str);
      }
    }
    /* Paint in the banner area */
    screen_area_puts(ge->banner, " The haunted castle game ");

    /* Paint in the help area */
    screen_area_clear(ge->help);
    sprintf(str, " The commands you can use are:");
    screen_area_puts(ge->help, str);
    sprintf(str, "     next or n, back or b, exit or e, left or l, right or r, take or t, drop or d, attack or a, chat or c");
    screen_area_puts(ge->help, str);
    msg = game_get_message_to_print(game);
    if (msg)
    {
      sprintf(str, "     %s", msg);
      screen_area_puts(ge->help, str);
      game_set_message_to_print(game, NULL);
    }

    /* Paint in the feedback area */
    last_cmd = command_get_code(game_get_last_command(game));
    sprintf(str, " %s (%s)", cmd_to_str[last_cmd - NO_CMD][CMDL], cmd_to_str[last_cmd - NO_CMD][CMDS]);
    screen_area_puts(ge->feedback, str);

    /* Dump to the terminal */
    screen_paint();
    printf("prompt:> ");
  }
}
