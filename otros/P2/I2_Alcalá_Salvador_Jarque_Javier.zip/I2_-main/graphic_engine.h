/**
 * @brief It defines the textual graphic engine interface
 *
 * @file graphic_engine.h
 * @author Profesores PPROG and Salvador Alcalá
 * @version 0
 * @date 8-02-2026
 * @copyright GNU Public License
 */

#ifndef GRAPHIC_ENGINE_H
#define GRAPHIC_ENGINE_H

#include "game.h"

typedef struct _Graphic_engine Graphic_engine;

/**
 * @brief It creates a new graphic engine, initializing it's members
 * @author Profesores PPROG
 *
 * @return a new graphic engine, initialized
 */
Graphic_engine *graphic_engine_create();

/**
 * @brief It destroys a graphic engine, freeing it's members memory and itself
 * @author Profesores PPROG
 *
 * @param ge the graphic engine to be destroyed
 */
void graphic_engine_destroy(Graphic_engine *ge);

/**
 * @brief It updates the graphic engine showing the current game status
 * @author Profesores PPROG
 *
 * @param ge the graphic engine to be updated
 * @param game the game with the information to be painted
 * @return a new graphic engine, initialized
 */
void graphic_engine_paint_game(Graphic_engine *ge, Game *game);

#endif
