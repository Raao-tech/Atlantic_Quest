/**
 * @brief It implements the object module
 *
 * @file object.c
 * @author Javier Jarque and Salvador Alcalá
 * @version 1.4
 * @date 10-03-2026
 * @copyright GNU Public License
 */

#include "object.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**
 * @brief Object
 *
 * This struct stores all the information of a object.
 */
struct _Object
{
  Id id;                    /*!< Id number of the object, it must be unique */
  char *gdesc;              /*!< Graphic description of the object*/
  char name[WORD_SIZE + 1]; /*!< Name of the object */
};

/** object_create allocates memory for a new object
 *  and initializes its members
 */
Object *object_create(Id id)
{
  Object *newObject = NULL;

  /* Error control */
  if (id == NO_ID)
    return NULL;

  newObject = (Object *)calloc(1, sizeof(Object));
  if (newObject == NULL)
  {
    return NULL;
  }

  /* Initialization of an empty object*/
  newObject->id = id;
  newObject->name[0] = '\0';

  return newObject;
}

void object_destroy(Object *object)
{
  if (object != NULL)
  {
    free(object->gdesc);
    free(object);
  }
}

Id object_get_id(Object *object)
{
  if (!object)
  {
    return NO_ID;
  }
  return object->id;
}

Status object_set_gdesc(Object *object, char *gdesc)
{
  if (!object || !gdesc)
  {
    return ERROR;
  }

  if (object->gdesc)
  {
    free(object->gdesc);
  }

  object->gdesc = gdesc;
  return OK;
}

char *object_get_gdesc(Object *object)
{
  if (!object)
  {
    return NULL;
  }
  return object->gdesc;
}

Status object_set_name(Object *object, char *name)
{
  if (!object || !name)
  {
    return ERROR;
  }

  strncpy(object->name, name, WORD_SIZE - 1);
  object->name[WORD_SIZE - 1] = '\0';
  return OK;
}

char *object_get_name(Object *object)
{
  if (!object)
  {
    return NULL;
  }
  return object->name;
}

Status object_print(Object *object)
{

  /* Error Control */
  if (!object)
  {
    return ERROR;
  }

  /* 1. Print the id and the name of the object */
  fprintf(stdout, "--> object (Id: %ld; Name: %s)\n", object->id, object->name);

  return OK;
}
