/**
 * @brief It defines the game interface
 *
 * @file object.h
 * @author Javier Jarque and Salvador Alcalá
 * @version 1.3
 * @date 15-03-2026
 * @copyright GNU Public License
 */

#ifndef OBJECT_H
#define OBJECT_H

#include "types.h"

/**
 * @brief Object
 *
 * This struct stores all the information of a object.
 */
typedef struct _Object Object;

/**
 * @brief It creates a new object, allocating memory and initializing its members
 * @author Javier Jarque and Salvador Alcalá
 *
 * @param id the identification number for the new object
 * @param space the location of the new object
 * @return a new object, initialized
 */
Object *object_create(Id id);

/**
 * @brief It destroys a object, freeing the allocated memory
 * @author Javier Jarque and Salvador Alcalá
 *
 * @param object a pointer to the object that must be destroyed
 */
void object_destroy(Object *object);

/**
 * @brief It gets the id of a object
 * @author Javier Jarque
 *
 * @param object a pointer to the object
 * @return the id of object
 */
Id object_get_id(Object *object);

/**
 * @brief It set the graphic description in the object
 * @author Salvador Alcala
 *
 * @param object a pointer to the object
 * @param gdesc a pointer to the graphic descripitom
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status object_set_gdesc(Object *object, char *gdesc);

/**
 * @brief It gets the gdesc of a object
 * @author Salvador Alcala
 *
 * @param object a pointer to the object
 * @return a pointer to the gdesc or NULL if it was some mistake
 */
char *object_get_gdesc(Object *object);

/**
 * @brief It sets the name of a object
 * @author Javier Jarque and Salvador Alcalá
 *
 * @param object a pointer to the object
 * @param name a string with the name to store
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status object_set_name(Object *object, char *name);

/**
 * @brief It gets the name of a object
 * @author Javier Jarque
 *
 * @param object a pointer to the object
 * @return  a string with the name of the object
 */
char *object_get_name(Object *object);

/**
 * @brief It prints the object information
 * @author Javier Jarque
 *
 * This fucntion shows the id and name of the object
 * @param object a pointer to the object
 * @return OK, if everything goes well or ERROR if there was some mistake
 */

Status object_print(Object *object);

#endif
