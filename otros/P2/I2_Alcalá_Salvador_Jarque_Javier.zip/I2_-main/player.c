/**
 * @brief It implements the player module
 *
 * @file player.c
 * @author Javier Jarque and Salvador Alcalá
 * @version 1.1
 * @date 15-02-2026
 * @copyright GNU Public License
 */

#include "player.h"
#include "set.h"
#include "types.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/**
 * @brief Object
 *
 * This struct stores all the information of a object.
 */
struct _Player
{
  Id id;                    /*!< Id number of the player, it must be unique */
  char name[WORD_SIZE + 1]; /*!< Name of the player */
  Id location;              /*!< Id location of the player */
  Set *objects;             /*!< The list of objects that the player has*/
  int health;               /*!< Health of the player */
  char *gdesc;              /*!< Graphic description of the player */
};

Player *player_create(Id id)
{
  Player *newPlayer = NULL;

  /* Error control */
  if (id == NO_ID)
    return NULL;

  newPlayer = (Player *)calloc(1, sizeof(Player));
  if (newPlayer == NULL)
  {
    return NULL;
  }

  /* Initialization of an empty player*/
  newPlayer->id = id;
  newPlayer->name[0] = '\0';
  newPlayer->location = NO_ID;
  newPlayer->objects = set_create();
  if (!newPlayer->objects)
  {
    return NULL;
  }
  newPlayer->health = MAX_PLAYER_HEALTH;
  newPlayer->gdesc = NULL;

  return newPlayer;
}

void player_destroy(Player *player)
{
  if (player != NULL)
  {
    if (player->gdesc)
    {
      free(player->gdesc);
    }
    if (player->objects)
    {
      set_destroy(player->objects);
    }
    free(player);
  }
}

Id player_get_id(Player *player)
{
  if (player == NULL)
  {
    return NO_ID;
  }
  return player->id;
}

Status player_set_id(Player *player, Id id)
{
  if (!player || id == NO_ID)
  {
    return ERROR;
  }
  player->id = id;
  return OK;
}

Status player_set_name(Player *player, char *name)
{
  if (!player || !name)
  {
    printf("name\n");
    return ERROR;
  }

  strncpy(player->name, name, WORD_SIZE - 1);
  player->name[WORD_SIZE - 1] = '\0';
  return OK;
}

const char *player_get_name(Player *player)
{
  if (!player)
  {
    return NULL;
  }
  return player->name;
}

Id player_get_location(Player *player)
{
  if (player == NULL)
  {
    return NO_ID;
  }
  return player->location;
}

Status player_set_location(Player *player, Id location)
{
  if (!player || location == NO_ID)
  {
    return ERROR;
  }
  player->location = location;
  return OK;
}

Status player_add_object(Player *player, Id object)
{
  if (!player)
  {
    return ERROR;
  }

  if (set_add(player->objects, object) == ERROR)
  {
    return ERROR;
  }
  return OK;
}

Status player_del_object(Player *player, Id object)
{
  if (!player)
  {
    return ERROR;
  }

  if (set_del(player->objects, object) == ERROR)
  {
    return ERROR;
  }
  return OK;
}

Bool player_find_object(Player *player, Id id)
{
  if (!player)
  {
    return FALSE;
  }
  return set_find_Id(player->objects, id) >= 0;
}

Id *player_get_objects(Player *player)
{
  if (!player)
  {
    return NULL;
  }
  return set_get_Ids(player->objects);
}

int player_get_number_of_objects(Player *player)
{
  if (!player || !player->objects)
  {
    return -1;
  }
  return set_get_n_Ids(player->objects);
}

int player_get_health(Player *player)
{
  if (player == NULL)
  {
    return -1;
  }
  return player->health;
}

Status player_set_health(Player *player, int health)
{
  if (!player)
  {

    return ERROR;
  }
  player->health = health;
  return OK;
}

Status player_set_gdesc(Player *player, char *gdesc)
{
  if (!player || !gdesc)
  {

    return ERROR;
  }

  if (player->gdesc)
  {
    free(player->gdesc);
  }

  player->gdesc = gdesc;
  return OK;
}

char *player_get_gdesc(Player *player)
{
  if (!player)
  {
    return NULL;
  }
  return player->gdesc;
}

Status player_print(Player *player)
{

  /* Error Control */
  if (!player)
  {
    return ERROR;
  }

  /* 1. Print the id and the name of the player */
  fprintf(stdout, "--> Player (Id: %ld; Name: %s)\n", player->id, player->name);

  /* 2. Print the location of the player*/
  fprintf(stdout, "--> Location (location: %ld)\n", player->location);

  /* 3. Print if the player has objects or not
  if (player_get_objects(player))
  {
    fprintf(stdout, "---> The player has an object.\n");
  }
  else
  {
    fprintf(stdout, "---> The player doesn't have an object.\n");
  }
*/
  return OK;
}