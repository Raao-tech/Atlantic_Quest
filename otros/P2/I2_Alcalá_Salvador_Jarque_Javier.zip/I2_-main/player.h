/**
 * @brief It defines the player module interface
 *
 * @file player.h
 * @author Javier Jarque and Salvador Alcala
 * @version 1.4
 * @date 16-03-2026
 * @copyright GNU Public License
 */

#ifndef PLAYER_H
#define PLAYER_H

#include "types.h"
#include "object.h"


#define MAX_PLAYER_HEALTH 10

/**
 * @brief Object
 *
 * This struct stores all the information of a player
 */
typedef struct _Player Player;

/**
 * @brief It creates a new player, allocating memory and initializing its members
 * @author Javier Jarque
 *
 * @param id the identification number for the new player
 * @return a new player, initialized
 */
Player *player_create(Id id);

/**
 * @brief It destroys a player, freeing the allocated memory
 * @author Javier Jarque and Salvador Alcala
 *
 * @param player a pointer to the player that must be destroyed
 */
void player_destroy(Player *player);

/**
 * @brief It gets the id of a player
 * @author Javier Jarque
 *
 * @param player a pointer to the player
 * @return the id of player
 */
Id player_get_id(Player *player);

/**
 * @brief If sets the id of a player
 * @author Javier Jarque and Salvador Alcala
 *
 * @param player a pointer to the player
 * @param id the id to set
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status player_set_id(Player *player, Id id);

/**
 * @brief It sets the name of a player
 * @author Javier Jarque
 *
 * @param player a pointer to the player
 * @param name a string with the name to store
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status player_set_name(Player *player, char *name);

/**
 * @brief It gets the name of a player
 * @author Javier Jarque
 *
 * @param player a pointer to the player
 * @return a string with the name of the player, or NULL if there was some mistake
 */
const char *player_get_name(Player *player);

/**
 * @brief It gets the location of a player
 * @author Javier Jarque
 *
 * @param player a pointer to the player
 * @return a string with the location of the player, or NO_ID if there was some mistake
 */
Id player_get_location(Player *player);

/**
 * @brief If sets the location of a player
 * @author Javier Jarque and Salvador Alcala
 *
 * @param player a pointer to the player
 * @param location the id of the location to set
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status player_set_location(Player *player, Id location);

/**
 * @brief It set the object in the player
 * @author Salvador Alcala
 *
 * @param player a pointer to the player
 * @param object the Id of the object
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status player_add_object(Player *player, Id object);

/**
 * @brief It deletes an id from the set
 * @author Salvador Alcalá
 * 
 * @param player the player from which the id will be deleted
 * @param id the id to be deleted
 * 
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status player_del_object(Player *player, Id object);

/**
 * @brief It gets whether the player has an object or not
 * @author Salvador Alcalá
 *
 * @param player a pointer to the player
 * @param id the object to be found
 * @return True of found, False otherwise
 */
Bool player_find_object(Player *player, Id id);

/**
 * @brief It gives the object that has the player
 * @author Javier Jarque and Salvador Alcala
 *
 * @param player a pointer to the player
 * @return a pointer to the list of objects in player or NULL if it was some mistake
 */
Id *player_get_objects(Player *player);

/**
 * @brief It gets the number of elemets on list of ids of the objects
 * @author Salvador Alcalá
 *
 * @param player a pointer to the player
 * @return The number of elements in the player, -1 otherwise
 */
int player_get_number_of_objects(Player *player);

/**
 * @brief It set the health of the player
 * @author Salvador Alcala
 *
 * @param player a pointer to the player
 * @param health the health to set
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status player_set_health(Player *player, int health);

/**
 * @brief It gives the health of the player
 * @author Salvador Alcala
 *
 * @param player a pointer to the player
 * @return the health of the player or -1 if it was some mistake
 */
int player_get_health(Player *player);

/**
 * @brief It set the graphic description in the player
 * @author Salvador Alcala
 *
 * @param player a pointer to the player
 * @param gdesc a pointer to the graphic descripitom
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status player_set_gdesc(Player *player, char *gdesc);

/**
 * @brief It gets the gdesc of a player
 * @author Salvador Alcala
 *
 * @param player a pointer to the player
 * @return a pointer to the gdesc or NULL if it was some mistake
 */
char *player_get_gdesc(Player *player);

/**
 * @brief It prints the player information
 * @author Profesores PPROG and Salvador Alcalá
 *
 * This fucntion shows the id and name of the player, the players that surrounds it and wheter it has an object or not.
 * @param player a pointer to the player
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status player_print(Player *player);

#endif