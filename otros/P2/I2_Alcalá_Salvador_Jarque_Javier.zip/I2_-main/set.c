/**
 * @brief It implements the set module
 *
 * @file set.c
 * @author Salvador Alcalá
 * @version 1.3
 * @date 03-03-2026
 * @copyright GNU Public License
 */

#include "set.h"

struct _Set
{
    Id *ids;   /*!< Pointer to the array of IDs in the set */
    int n_ids; /*!< Number of IDs currently in the set */
};

Set *set_create()
{
    Set *set = NULL;
    set = (Set *)malloc(1 * sizeof(Set));
    if (!set)
    {
        return NULL;
    }
    set->n_ids = 0;
    set->ids = (Id *)calloc(1, sizeof(Id));
    if (!set->ids)
    {
        set_destroy(set);
        return NULL;
    }
    return set;
}

void set_destroy(Set *set)
{
    if (set != NULL)
    {
        if (set->ids != NULL)
        {
            free(set->ids);
        }
        free(set);
    }
}

Status set_add(Set *set, Id id)
{
    Id *aux = NULL;
    if (!set || id < 1)
    {
        return ERROR;
    }
    set->n_ids++;
    aux = realloc(set->ids, set->n_ids * sizeof(Id));
    if (!aux)
    {
        return ERROR;
    }

    set->ids = aux;
    set->ids[set->n_ids - 1] = id;

    return OK;
}

Status set_del(Set *set, Id id)
{
    int pos;
    if (!set || id < 1 || set->n_ids < 1)
    {
        return ERROR;
    }

    pos = set_find_Id(set, id);

    if (pos == -1)
    {
        return ERROR;
    }

    set->ids[pos] = set->ids[set->n_ids - 1];

    set->n_ids--;

    return OK;
}

int set_find_Id(Set *set, Id id)
{
    int bucle;

    if (!set || id < 1)
    {
        return -1;
    }
    for (bucle = 0; bucle < set->n_ids; bucle++)
    {
        if (set->ids[bucle] == id)
        {
            return bucle;
        }
    }
    return -1;
}

int set_get_n_Ids(Set *set)
{
    if (!set || set->n_ids < 0)
    {
        return -1;
    }

    return set->n_ids;
}
Id *set_get_Ids(Set *set)
{
    if (!set)
    {
        return NULL;
    }

    return set->ids;
}

void set_print(Set *set)
{
    int bucle;
    if (!set)
    {
        printf("Empty set");
        return;
    }
    printf("Number of ids: %d\nIds stored: ", (int)set->n_ids);

    for (bucle = 0; bucle < set->n_ids; bucle++)
    {
        printf("%d ", (int)set->ids[bucle]);
    }
}
