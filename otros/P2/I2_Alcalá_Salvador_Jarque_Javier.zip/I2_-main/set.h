/**
 * @brief It defines the set interpreter interface
 *
 * @file set.h
 * @author Salvador Alcalá
 * @version 1.2
 * @date 15-03-2026
 * @copyright GNU Public License
 */

#include "types.h"
#include <stdio.h>
#include <stdlib.h>

#define MAX_IDS 100

/**
 * @brief Set
 *
 * This struct stores all the information of a set.
 */
typedef struct _Set Set;

/**
 * @brief It creates a new set, allocating memory and initializing its members
 * @author Salvador Alcalá
 *
 * @return a new set, initialized
 */
Set *set_create();

/**
 * @brief It destroys a set, freeing all allocated memory
 * @author Salvador Alcalá
 *
 * @param set the set to be destroyed
 */
void set_destroy(Set *set);

/**
 * @brief It adds an id to the set
 * @author Salvador Alcalá
 * 
 * @param set the set to which the id will be added
 * @param id the id to be added
 * 
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status set_add(Set *set, Id id);

/**
 * @brief It deletes an id from the set
 * @author Salvador Alcalá
 * 
 * @param set the set from which the id will be deleted
 * @param id the id to be deleted
 * 
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status set_del(Set *set, Id id);

/**
 * @brief It finds the position of an id in the set
 * @author Salvador Alcalá
 * 
 * @param set the set in which the id will be searched
 * @param id the id to be searched
 * 
 * @return the position of the id in the set, or -1 if it was not found or if there was some mistake
 */
int set_find_Id(Set *set, Id id);

/**
 * @brief It gets the number of Ids stored in a set
 * @author Salvador Alcalá
 *
 * @param set a pointer to the set
 * @return the number of Ids, -1 in case of error
 */
int set_get_n_Ids(Set *set);

/**
 * @brief It gets the list of Ids stored in a set
 * @author Salvador Alcalá
 *
 * @param set a pointer to the set
 * @return the list of Ids, NULL in case of error
 */
Id *set_get_Ids (Set *set);

/**
 * @brief It prints the information of the set
 * @author Salvador Alcalá
 * 
 * @param set the set to be printed
 */
void set_print(Set *set);
