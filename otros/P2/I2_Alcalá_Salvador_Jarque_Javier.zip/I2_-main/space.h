/**
 * @brief It defines the space module interface
 *
 * @file space.h
 * @author Profesores PPROG, Salvador Alcalá y Javier Jarque
 * @version 1.6
 * @date 15-03-2025
 * @copyright GNU Public License
 */

#ifndef SPACE_H
#define SPACE_H

#include "types.h"



typedef struct _Space Space;

/**
 * @brief It creates a new space, allocating memory and initializing its members
 * @author Profesores PPROG and Salvador Alcalá
 *
 * @param id the identification number for the new space
 * @return a new space, initialized
 */
Space *space_create(Id id);

/**
 * @brief It destroys a space, freeing the allocated memory
 * @author Profesores PPROG and Salvador Alcalá
 *
 * @param space a pointer to the space that must be destroyed
 */
void space_destroy(Space *space);

/**
 * @brief It gets the id of a space
 * @author Profesores PPROG
 *
 * @param space a pointer to the space
 * @return the id of space
 */
Id space_get_id(Space *space);

/**
 * @brief It sets the name of a space
 * @author Profesores PPROG
 *
 * @param space a pointer to the space
 * @param name a string with the name to store
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status space_set_name(Space *space, char *name);

/**
 * @brief It gets the name of a space
 * @author Profesores PPROG
 *
 * @param space a pointer to the space
 * @return  a string with the name of the space
 */
const char *space_get_name(Space *space);

/**
 * @brief It sets the id of the space located at the north
 * @author Profesores PPROG
 *
 * @param space a pointer to the space
 * @param id the id number of the space located at the north
 * @return OK, if everything goes well or ERROR if there was some mistake
 */

Status space_set_north(Space *space, Id id);

/**
 * @brief It gets the id of the space located at the north
 * @author Profesores PPROG
 *
 * @param space a pointer to the space
 * @return the id number of the space located at the north
 */
Id space_get_north(Space *space);

/**
 * @brief It sets the id of the space located at the south
 * @author Profesores PPROG
 *
 * @param space a pointer to the space
 * @param id the id number of the space located at the south
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status space_set_south(Space *space, Id id);

/**
 * @brief It gets the id of the space located at the south
 * @author Profesores PPROG
 *
 * @param space a pointer to the space
 * @return the id number of the space located at the south
 */
Id space_get_south(Space *space);

/**
 * @brief It sets the id of the space located at the east
 * @author Profesores PPROG
 *
 * @param space a pointer to the space
 * @param id the id number of the space located at the east
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status space_set_east(Space *space, Id id);

/**
 * @brief It gets the id of the space located at the east
 * @author Profesores PPROG
 *
 * @param space a pointer to the space
 * @return the id number of the space located at the east
 */
Id space_get_east(Space *space);

/**
 * @brief It sets the id of the space located at the west
 * @author Profesores PPROG
 *
 * @param space a pointer to the space
 * @param id the id number of the space located at the west
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status space_set_west(Space *space, Id id);

/**
 * @brief It gets the id of the space located at the west
 * @author Teachers PPROG
 *
 * @param space a pointer to the space
 * @return the id number of the space located at the west
 */
Id space_get_west(Space *space);

/**
 * @brief It adds a new object id to the set
 * @author Salvador Alcalá
 *
 * @param space a pointer to the space
 * @param obj object to be added
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status space_add_object(Space *space, Id obj);

/**
 * @brief It deletes an id from the space
 * @author Salvador Alcalá
 * 
 * @param space the space from which the id will be deleted
 * @param id the id to be deleted
 * 
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status space_del_object(Space *space, Id object);

/**
 * @brief It gets whether the space has an object or not
 * @author Salvador Alcalá
 *
 * @param space a pointer to the space
 * @param id the object to be found
 * @return True of found, False otherwise
 */
Bool space_find_object(Space *space, Id id);

/**
 * @brief It gets the list of ids of the objects
 * @author Salvador Alcalá
 *
 * @param space a pointer to the space
 * @return A pointer to the lit of ids, NULL otherwise
 */
Id *space_get_objects(Space *space);

/**
 * @brief It gets the number of elemets on list of ids of the objects
 * @author Salvador Alcalá
 *
 * @param space a pointer to the space
 * @return The number of elements in the space, -1 otherwise
 */
int space_get_number_of_objects(Space *space);

/**
 * @brief It adds a new character id to the set
 * @author Javier Jarque
 *
 * @param space a pointer to the space
 * @param character character to be added
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status space_add_character(Space *space, Id character);

/**
 * @brief It deletes an id of a character from the space
 * @author Javier Jarque
 * 
 * @param space the space from which the id will be deleted
 * @param object the id of the character to be deleted
 * 
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status space_del_character(Space *space, Id object);

/**
 * @brief It gets whether the space has an character or not
 * @author Javier Jarque
 *
 * @param space a pointer to the space
 * @param id the object to be found
 * @return True of found, False otherwise
 */
Bool space_find_character(Space *space, Id id);

/**
 * @brief It gets the list of ids of the characters
 * @author Javier Jarque
 *
 * @param space a pointer to the space
 * @return A pointer to the lit with the ids of the characters, NULL otherwise
 */
Id *space_get_characters(Space *space);

/**
 * @brief It gets the number of elemets on list of ids of the characters
 * @author Javier Jarque
 *
 * @param space a pointer to the space
 * @return The number of characters in the space, -1 otherwise
 */
int space_get_number_of_characters(Space *space);

/**
 * @brief It sets the graphic description of a space
 * @author Salvador Alcalá
 *
 * @param space a pointer to the space
 * @param gdesc the gdesc to be set
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status space_set_gdesc (Space *space, char *gdesc [MAX_ROWS]);

/**
 * @brief It gets the graphic description of a space
 * @author Salvador Alcalá
 *
 * @param space a pointer to the space
 * @return A pointer to the graphic description, NULL otherwise
 */
char **space_get_gdesc (Space *space);

/**
 * @brief It prints the space information
 * @author Profesores PPROG
 *
 * This fucntion shows the id and name of the space, the spaces that surrounds it and wheter it has an object or not.
 * @param space a pointer to the space
 * @return OK, if everything goes well or ERROR if there was some mistake
 */
Status space_print(Space *space);

#endif