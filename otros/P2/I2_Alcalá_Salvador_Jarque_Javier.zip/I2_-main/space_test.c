/** 
 * @brief It tests space module
 * 
 * @file space_test.c
 * @author Profesores Pprog
 * @version 0.0 
 * @date 17-02-2025
 * @copyright GNU Public License
 */

#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include "space.h"
#include "space_test.h"
#include "test.h"

#define MAX_TESTS 50

/** 
 * @brief Main function for SPACE unit tests. 
 * 
 * You may execute ALL or a SINGLE test
 *   1.- No parameter -> ALL test are executed 
 *   2.- A number means a particular test (the one identified by that number) 
 *       is executed
 *  
 */
int main(int argc, char** argv) {

  int test = 0;
  int all = 1;

  if (argc < 2) {
    printf("Running all test for module Space:\n");
  } else {
    test = atoi(argv[1]);
    all = 0;
    printf("Running test %d:\t", test);
    if (test < 1 && test > MAX_TESTS) {
      printf("Error: unknown test %d\t", test);
      exit(EXIT_SUCCESS);
    }
  }


  if (all ==1 || test == 1) test1_space_create();
  if (all ==1|| test == 2) test2_space_create();
  if (all ==1 || test == 3) test1_space_set_name();
  if (all ==1|| test == 4) test2_space_set_name();
  if (all ==1 || test == 5) test3_space_set_name();
  if (all ==1 || test == 6) test1_space_set_north();
  if (all ==1 || test == 7) test2_space_set_north();
  if (all ==1 || test == 8) test1_space_set_south();
  if (all ==1 || test == 9) test2_space_set_south();
  if (all ==1 || test == 10) test1_space_set_east();
  if (all ==1 || test == 11) test2_space_set_east();
  if (all ==1 || test == 12) test1_space_set_west();
  if (all ==1 || test == 13) test2_space_set_west();
if (all == 1 || test == 14) test1_space_get_id();
if (all == 1 || test == 15) test2_space_get_id();

if (all == 1 || test == 16) test1_space_get_name();
if (all == 1 || test == 17) test2_space_get_name();

if (all == 1 || test == 18) test1_space_get_north();
if (all == 1 || test == 19) test2_space_get_north();

if (all == 1 || test == 20) test1_space_get_south();
if (all == 1 || test == 21) test2_space_get_south();

if (all == 1 || test == 22) test1_space_get_east();
if (all == 1 || test == 23) test2_space_get_east();

if (all == 1 || test == 24) test1_space_get_west();
if (all == 1 || test == 25) test2_space_get_west();

if (all == 1 || test == 26) test1_space_add_object();
if (all == 1 || test == 27) test2_space_add_object();

if (all == 1 || test == 28) test1_space_del_object();
if (all == 1 || test == 29) test2_space_del_object();

if (all == 1 || test == 30) test1_space_find_object();
if (all == 1 || test == 31) test2_space_find_object();

if (all == 1 || test == 32) test1_space_get_objects();
if (all == 1 || test == 33) test2_space_get_objects();

if (all == 1 || test == 34) test1_space_get_number_of_objects();
if (all == 1 || test == 35) test2_space_get_number_of_objects();

if (all == 1 || test == 36) test1_space_add_character();
if (all == 1 || test == 37) test2_space_add_character();

if (all == 1 || test == 38) test1_space_del_character();
if (all == 1 || test == 39) test2_space_del_character();

if (all == 1 || test == 40) test1_space_find_character();
if (all == 1 || test == 41) test2_space_find_character();

if (all == 1 || test == 42) test1_space_get_characters();
if (all == 1 || test == 43) test2_space_get_characters();

if (all == 1 || test == 44) test1_space_get_number_of_characters();
if (all == 1 || test == 45) test2_space_get_number_of_characters();

if (all == 1 || test == 46) test1_space_set_gdesc();
if (all == 1 || test == 47) test2_space_set_gdesc();

if (all == 1 || test == 48) test1_space_get_gdesc();
if (all == 1 || test == 49) test2_space_get_gdesc();


  PRINT_PASSED_PERCENTAGE;

  return 0;
}

void test1_space_create() {
  int result;
  Space *s;
  s = space_create(5);
  result=s!=NULL ;
  PRINT_TEST_RESULT(result);
  space_destroy(s);
}

void test2_space_create() {
  Space *s;
  s = space_create(4);
  PRINT_TEST_RESULT(space_get_id(s) == 4);
  space_destroy(s);
}

void test1_space_set_name() {
  Space *s;
  s = space_create(5);
  PRINT_TEST_RESULT(space_set_name(s, "hola") == OK);
  space_destroy(s);
}

void test2_space_set_name() {
  Space *s = NULL;
  PRINT_TEST_RESULT(space_set_name(s, "hola") == ERROR);
}

void test3_space_set_name() {
  Space *s;
  s = space_create(5);
  PRINT_TEST_RESULT(space_set_name(s, NULL) == ERROR);
  space_destroy(s);
}

void test1_space_set_north() {
  Space *s;
  s = space_create(5);
  PRINT_TEST_RESULT(space_set_north(s, 4) == OK);
  space_destroy(s);
}

void test2_space_set_north() {
  Space *s = NULL;
  PRINT_TEST_RESULT(space_set_north(s, 4) == ERROR);
}

void test1_space_set_south() {
  Space *s;
  s = space_create(5);
  PRINT_TEST_RESULT(space_set_south(s, 4) == OK);
  space_destroy(s);
}

void test2_space_set_south() {
  Space *s = NULL;
  PRINT_TEST_RESULT(space_set_south(s, 4) == ERROR);
}

void test1_space_set_east() {
  Space *s;
  s = space_create(5);
  PRINT_TEST_RESULT(space_set_east(s, 4) == OK);
  space_destroy(s);
}

void test2_space_set_east() {
  Space *s = NULL;
  PRINT_TEST_RESULT(space_set_east(s, 4) == ERROR);
}

void test1_space_set_west() {
  Space *s;
  s = space_create(5);
  PRINT_TEST_RESULT(space_set_west(s, 4) == OK);
  space_destroy(s);
}

void test2_space_set_west() {
  Space *s = NULL;
  PRINT_TEST_RESULT(space_set_west(s, 4) == ERROR);
}

void test1_space_set_object() {
  Space *s;
  s = space_create(1);
  PRINT_TEST_RESULT(space_add_object(s,12) == OK);
  space_destroy(s);
}

void test2_space_set_object() {
  Space *s = NULL;
  PRINT_TEST_RESULT(space_add_object(s,13) == ERROR);
}

void test1_space_get_name() {
  Space *s;
  s = space_create(1);
  space_set_name(s, "adios");
  PRINT_TEST_RESULT(strcmp(space_get_name(s), "adios") == 0);
  space_destroy(s);
}

void test2_space_get_name() {
  Space *s = NULL;
  PRINT_TEST_RESULT(space_get_name(s) == NULL);
}

void test1_space_get_north() {
  Space *s;
  s = space_create(5);
  space_set_north(s, 4);
  PRINT_TEST_RESULT(space_get_north(s) == 4);
  space_destroy(s);
}

void test2_space_get_north() {
  Space *s = NULL;
  PRINT_TEST_RESULT(space_get_north(s) == NO_ID);
}

void test1_space_get_south() {
  Space *s;
  s = space_create(5);
  space_set_south(s, 2);
  PRINT_TEST_RESULT(space_get_south(s) == 2);
  space_destroy(s);
}

void test2_space_get_south() {
  Space *s = NULL;
  PRINT_TEST_RESULT(space_get_south(s) == NO_ID);
}

void test1_space_get_east() {
  Space *s;
  s = space_create(5);
  space_set_east(s, 1);
  PRINT_TEST_RESULT(space_get_east(s) == 1);
  space_destroy(s);
}

void test2_space_get_east() {
  Space *s = NULL;
  PRINT_TEST_RESULT(space_get_east(s) == NO_ID);
}

void test1_space_get_west() {
  Space *s;
  s = space_create(5);
  space_set_west(s, 6);
  PRINT_TEST_RESULT(space_get_west(s) == 6);
  space_destroy(s);
}

void test2_space_get_west() {
  Space *s = NULL;
  PRINT_TEST_RESULT(space_get_west(s) == NO_ID);
}

void test1_space_get_id() {
  Space *s;
  s = space_create(25);
  PRINT_TEST_RESULT(space_get_id(s) == 25);
  space_destroy(s);
}

void test2_space_get_id() {
  Space *s = NULL;
  PRINT_TEST_RESULT(space_get_id(s) == NO_ID);
}
void test1_space_add_object()
{
    Space *s;
  s = space_create(25);
  PRINT_TEST_RESULT(space_add_object(s,8) == OK);
  space_destroy(s);
}
void test2_space_add_object()
{
    Space *s=NULL;
  PRINT_TEST_RESULT(space_add_object(s,8) == ERROR);
  space_destroy(s);
}
void test1_space_del_object()
{
      Space *s;
  s = space_create(25);
  space_add_object(s,8);
  PRINT_TEST_RESULT(space_del_object(s,8) == OK);
  space_destroy(s);
}
void test2_space_del_object()
{
  Space *s;
  s = space_create(25);
  PRINT_TEST_RESULT(space_del_object(s,8) == ERROR);
  space_destroy(s);
}
void test1_space_find_object()
{
      Space *s;
  s = space_create(25);
  space_add_object(s,8);
   PRINT_TEST_RESULT(space_find_object(s,8) == TRUE);
  space_destroy(s);
}
void test2_space_find_object()
{
      Space *s;
  s = space_create(25);
  space_add_object(s,8);
   PRINT_TEST_RESULT(space_find_object(s,9) == FALSE);
  space_destroy(s);
}
void test1_space_get_objects()
{
    Space *s;
  s = space_create(25);
  PRINT_TEST_RESULT(space_get_objects(s)!=NULL);
  space_destroy(s);
}
void test2_space_get_objects()
{ 
  Space *s = NULL;
  PRINT_TEST_RESULT(!space_get_objects(s));
}
void test1_space_get_number_of_objects()
  {
    Space *s;
  s = space_create(25);
   space_add_object(s,8);
  PRINT_TEST_RESULT(space_get_number_of_objects(s)==1);
  space_destroy(s);
}
void test2_space_get_number_of_objects()
 {
    Space *s=NULL;
    PRINT_TEST_RESULT(space_get_number_of_objects(s)==-1);
}
void test1_space_add_character()
{
      Space *s;
  s = space_create(25);
   PRINT_TEST_RESULT(space_add_character(s,8)==OK);
  space_destroy(s);
}
void test2_space_add_character()
 {
    Space *s=NULL;
    PRINT_TEST_RESULT(space_add_character(s,8)==ERROR);
}
void test1_space_del_character()
{
        Space *s;
  s = space_create(25);
  space_add_character(s,8);
  PRINT_TEST_RESULT(space_del_character(s,8) == OK);
  space_destroy(s);
}
void test2_space_del_character()
{
   Space *s;
  s = space_create(25);
    PRINT_TEST_RESULT(space_del_character(s,8)==ERROR);
}
void test1_space_find_character()
{
        Space *s;
  s = space_create(25);
  space_add_character(s,8);
  PRINT_TEST_RESULT(space_find_character(s,8) == TRUE);
  space_destroy(s);
}
void test2_space_find_character()
{
        Space *s;
  s = space_create(25);
  space_add_character(s,8);
  PRINT_TEST_RESULT(space_find_character(s,9) == FALSE);
  space_destroy(s);
}
void test1_space_get_characters()
{
    Space *s;
  s = space_create(25);
  PRINT_TEST_RESULT(space_get_characters(s)!=NULL);
  space_destroy(s);
}
void test2_space_get_characters()
{ 
  Space *s = NULL;
  PRINT_TEST_RESULT(!space_get_characters(s));
}
void test1_space_get_number_of_characters()
  {
    Space *s;
  s = space_create(25);
   space_add_character(s,8);
  PRINT_TEST_RESULT(space_get_number_of_characters(s)==1);
  space_destroy(s);
}
void test2_space_get_number_of_characters()
 {
    Space *s=NULL;
    PRINT_TEST_RESULT(space_get_number_of_characters(s)==-1);
}
void test1_space_set_gdesc() {
  Space *s;
  char *l[MAX_ROWS];
  int bucle, i;
  for (bucle = 0; bucle < MAX_ROWS; bucle++)
  {
    l[bucle] = (char *)calloc((MAX_COLUMNS + 1), sizeof(char));
    if (l[bucle] == NULL)
   {
     for (i = 0; i < bucle; i++)
      {
         free(l[i]);
      }
      printf("test de la l. 427 fallido \n");
      return;
    }
  }
  s = space_create(5);
  PRINT_TEST_RESULT(space_set_gdesc(s, l) == OK);
  space_destroy(s);
}

void test2_space_set_gdesc() 
{
  Space *s = NULL;
    char *l[MAX_ROWS];
    int bucle,i;
    for (bucle = 0; bucle < MAX_ROWS; bucle++)
  {
    l[bucle] = (char *)calloc((MAX_COLUMNS + 1), sizeof(char));
    if (l[bucle] == NULL)
   {
     for (i = 0; i < bucle; i++)
      {
         free(l[i]);
      }
      printf("test de la l. 449 fallido \n");
      return;
    }
  }
  
  PRINT_TEST_RESULT(space_set_gdesc(s, l) == ERROR);

  for (i = 0; i < bucle; i++)
      {
         free(l[i]);
      }
}
void test1_space_get_gdesc ()
{
    Space *s;
  char *l[MAX_ROWS];
  int bucle,i;
  s = space_create(5);
   for (bucle = 0; bucle < MAX_ROWS; bucle++)
  {
    l[bucle] = (char *)calloc((MAX_COLUMNS + 1), sizeof(char));
    if (l[bucle] == NULL)
   {
     for (i = 0; i < bucle; i++)
      {
         free(l[i]);
      }
      printf("test de la l. 470 fallido \n");
      return;
    }
  }
  space_set_gdesc(s, l); 
  PRINT_TEST_RESULT(space_get_gdesc(s)!=NULL);
  space_destroy(s);
}
void test2_space_get_gdesc ()
{ 
Space *s = NULL;
  PRINT_TEST_RESULT(space_get_gdesc(s) == NULL);
}
