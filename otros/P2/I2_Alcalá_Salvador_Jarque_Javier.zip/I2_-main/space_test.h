/** 
 * @brief It declares the tests for the space module
 * 
 * @file space_test.h
 * @author Profesores Pprog and Salvador Alcalá
 * @version 1.0 
 * @date 16-03-2026
 * @copyright GNU Public License
 */

#ifndef SPACE_TEST_H
#define SPACE_TEST_H

/**
 * @test Test function for space_north setting
 * @pre Valid space pointer and north id
 * @post Output == OK
 */
void test1_space_set_north();

/**
 * @test Test function for space_north setting
 * @pre Space pointer = NULL
 * @post Output == ERROR
 */
void test2_space_set_north();

/**
 * @test Test function for space_north setting
 * @pre Invalid north id
 * @post Output == ERROR
 */
void test3_space_set_north();

/**
 * @test Test function for space_north setting
 * @pre Valid parameters
 * @post Space north == Supplied id
 */
void test4_space_set_north();

/**
 * @test Test function for space_south setting
 * @pre Valid space pointer and south id
 * @post Output == OK
 */
void test1_space_set_south();

/**
 * @test Test function for space_south setting
 * @pre Space pointer = NULL
 * @post Output == ERROR
 */
void test2_space_set_south();

/**
 * @test Test function for space_south setting
 * @pre Invalid south id
 * @post Output == ERROR
 */
void test3_space_set_south();

/**
 * @test Test function for space_south setting
 * @pre Valid parameters
 * @post Space south == Supplied id
 */
void test4_space_set_south();

/**
 * @test Test function for space_east setting
 * @pre Valid space pointer and east id
 * @post Output == OK
 */
void test1_space_set_east();

/**
 * @test Test function for space_east setting
 * @pre Space pointer = NULL
 * @post Output == ERROR
 */
void test2_space_set_east();

/**
 * @test Test function for space_east setting
 * @pre Invalid east id
 * @post Output == ERROR
 */
void test3_space_set_east();

/**
 * @test Test function for space_east setting
 * @pre Valid parameters
 * @post Space east == Supplied id
 */
void test4_space_set_east();

/**
 * @test Test function for space_west setting
 * @pre Valid space pointer and west id
 * @post Output == OK
 */
void test1_space_set_west();

/**
 * @test Test function for space_west setting
 * @pre Space pointer = NULL
 * @post Output == ERROR
 */
void test2_space_set_west();

/**
 * @test Test function for space_west setting
 * @pre Invalid west id
 * @post Output == ERROR
 */
void test3_space_set_west();

/**
 * @test Test function for space_west setting
 * @pre Valid parameters
 * @post Space west == Supplied id
 */
void test4_space_set_west();

/**
 * @test Test function for space_object setting
 * @pre Valid space pointer and object id
 * @post Output == OK
 */
void test1_space_set_object();

/**
 * @test Test function for space_object setting
 * @pre Space pointer = NULL
 * @post Output == ERROR
 */
void test2_space_set_object();

/**
 * @test Test function for space_get_id
 * @pre Valid space pointer
 * @post Output == Space id
 */
void test1_space_get_id();

/**
 * @test Test function for space_get_id
 * @pre Space pointer = NULL
 * @post Output == NULL
 */
void test2_space_get_id();

/**
 * @test Test function for space_get_name
 * @pre Valid space pointer
 * @post Output == Space name
 */
void test1_space_get_name();

/**
 * @test Test function for space_get_name
 * @pre Space pointer = NULL
 * @post Output == NULL
 */
void test2_space_get_name();

/**
 * @test Test function for space_get_north
 * @pre Valid space pointer
 * @post Output == North id
 */
void test1_space_get_north();

/**
 * @test Test function for space_get_north
 * @pre Space pointer = NULL
 * @post Output == NULL
 */
void test2_space_get_north();

/**
 * @test Test function for space_get_south
 * @pre Valid space pointer
 * @post Output == South id
 */
void test1_space_get_south();

/**
 * @test Test function for space_get_south
 * @pre Space pointer = NULL
 * @post Output == NULL
 */
void test2_space_get_south();

/**
 * @test Test function for space_get_east
 * @pre Valid space pointer
 * @post Output == East id
 */
void test1_space_get_east();

/**
 * @test Test function for space_get_east
 * @pre Space pointer = NULL
 * @post Output == NULL
 */
void test2_space_get_east();

/**
 * @test Test function for space_get_west
 * @pre Valid space pointer
 * @post Output == West id
 */
void test1_space_get_west();

/**
 * @test Test function for space_get_west
 * @pre Space pointer = NULL
 * @post Output == NULL
 */
void test2_space_get_west();

/**
 * @test Test function for space_add_object
 * @pre Valid space pointer and object id
 * @post Output == OK
 */
void test1_space_add_object();

/**
 * @test Test function for space_add_object
 * @pre Space pointer = NULL
 * @post Output == ERROR
 */
void test2_space_add_object();

/**
 * @test Test function for space_del_object
 * @pre Valid space pointer and object id present
 * @post Output == OK
 */
void test1_space_del_object();

/**
 * @test Test function for space_del_object
 * @pre Space pointer = NULL
 * @post Output == ERROR
 */
void test2_space_del_object();

/**
 * @test Test function for space_find_object
 * @pre Object id present in space
 * @post Output != NULL
 */
void test1_space_find_object();

/**
 * @test Test function for space_find_object
 * @pre Object id not present
 * @post Output == NULL
 */
void test2_space_find_object();

/**
 * @test Test function for space_get_objects
 * @pre Valid space pointer
 * @post Output != NULL
 */
void test1_space_get_objects();

/**
 * @test Test function for space_get_objects
 * @pre Space pointer = NULL
 * @post Output == NULL
 */
void test2_space_get_objects();

/**
 * @test Test function for space_get_number_of_objects
 * @pre Valid space pointer
 * @post Output == number of objects in space
 */
void test1_space_get_number_of_objects();

/**
 * @test Test function for space_get_number_of_objects
 * @pre Space pointer = NULL
 * @post Output == 0
 */
void test2_space_get_number_of_objects();

/**
 * @test Test function for space_add_character
 * @pre Valid space pointer and character id
 * @post Output == OK
 */
void test1_space_add_character();

/**
 * @test Test function for space_add_character
 * @pre Space pointer = NULL
 * @post Output == ERROR
 */
void test2_space_add_character();

/**
 * @test Test function for space_del_character
 * @pre Valid space pointer and character present
 * @post Output == OK
 */
void test1_space_del_character();

/**
 * @test Test function for space_del_character
 * @pre Space pointer = NULL
 * @post Output == ERROR
 */
void test2_space_del_character();

/**
 * @test Test function for space_find_character
 * @pre Character present in space
 * @post Output != NULL
 */
void test1_space_find_character();

/**
 * @test Test function for space_find_character
 * @pre Character not present
 * @post Output == NULL
 */
void test2_space_find_character();

/**
 * @test Test function for space_get_characters
 * @pre Valid space pointer
 * @post Output != NULL
 */
void test1_space_get_characters();

/**
 * @test Test function for space_get_characters
 * @pre Space pointer = NULL
 * @post Output == NULL
 */
void test2_space_get_characters();

/**
 * @test Test function for space_get_number_of_characters
 * @pre Valid space pointer
 * @post Output == number of characters
 */
void test1_space_get_number_of_characters();

/**
 * @test Test function for space_get_number_of_characters
 * @pre Space pointer = NULL
 * @post Output == 0
 */
void test2_space_get_number_of_characters();

/**
 * @test Test function for space_gdesc setting
 * @pre Valid space pointer and gdesc string
 * @post Output == OK
 */
void test1_space_set_gdesc();

/**
 * @test Test function for space_gdesc setting
 * @pre Space pointer = NULL
 * @post Output == ERROR
 */
void test2_space_set_gdesc();

/**
 * @test Test function for space_get_gdesc
 * @pre Valid space pointer
 * @post Output != NULL
 */
void test1_space_get_gdesc();

/**
 * @test Test function for space_get_gdesc
 * @pre Space pointer = NULL
 * @post Output == NULL
 */
void test2_space_get_gdesc();

#endif
