/**
 * @brief It defines common types for the whole project
 *
 * @file types.h
 * @author Profesores PPROG and Salvador Alcalá
 * @version 1
 * @date 09-03-2026
 * @copyright GNU Public License
 */

#ifndef TYPES_H
#define TYPES_H

#define WORD_SIZE 1000
#define NO_ID -1
#define MAX_ROWS 5
#define MAX_COLUMNS 9
#define MAX_OBJ_TO_SHOW 3


typedef long Id;

typedef enum
{
    FALSE,
    TRUE
} Bool;

typedef enum
{
    ERROR,
    OK
} Status;

typedef enum
{
    N,
    S,
    E,
    W
} Direction;

#endif
